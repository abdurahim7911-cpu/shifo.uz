# MedCare — Frontend + Backend

Loyiha React + Vite frontend va Express + MongoDB backenddan iborat. Backend ishga tushganda sun’iy shifokor/bemor/uchrashuvlar avtomatik yaratilmaydi.

## 1. Kerakli dasturlar
- Node.js LTS va npm
- MongoDB Atlas akkaunti yoki ishlayotgan MongoDB serveri

## 2. MongoDB ulanishini sozlash
1. `backend` papkasidagi `.env.example` faylidan nusxa olib, shu papkada `.env` nomi bilan saqlang.
2. `.env` ichidagi `MONGO_URI` qiymatini o‘zingizning Atlas connection stringingiz bilan almashtiring. Parolingizni hech kimga yubormang.
3. `.env` fayli Gitga qo‘shilmaydi.

## 3. O‘rnatish
Loyiha ildizidagi terminalda:

```bash
npm run setup
```

## 4. Frontend va backendni birga ishga tushirish
Loyiha ildizidagi terminalda:

```bash
npm run dev
```

Frontend: http://localhost:5173
Backend holati: http://localhost:5000/api/health

Agar health manzili `ok: true` qaytarsa, backend ishlayapti va MongoDBga ulangan.

## 5. Admin yaratish
`.env` sozlangan va MongoDBga ulanish ishlayotganidan keyin:

```bash
npm run create-admin
```

Hozirgi backend skripti boshlang‘ich adminni `admin@medcare.com` / `admin123` bilan yaratadi. Birinchi kirishdan keyin parolni almashtiring; bu parolni internetda yoki ommaviy repozitoriyda saqlamang.

## 6. Eski demo yozuvlarini o‘chirish (ixtiyoriy)
Bazadagi faqat kodda belgilangan demo email manzillariga tegishli bemorlar/shifokorlar va ularga bog‘langan uchrashuvlar o‘chiriladi. Avval bazani tekshirib oling.

```bash
npm run clean-demo
```

Bu buyruq ma’lumotlar bazasini o‘zgartiradi. Bo‘limlar va admin akkaunti o‘chirilmaydi.

## Qo‘shimcha tuzatishlar

- Dashboard bo‘limi `#/dashboard`, `#/doctors`, `#/patients`, `#/appointments`, `#/departments` hash yo‘llaridan foydalanadi. Shu sabab `Ctrl+R` bosilganda tanlangan sahifa saqlanadi.
- Kirilgan foydalanuvchi brauzer `localStorage`ida saqlanadi; Logout tugmasi bosilganda sessiya tozalanadi.
- New Appointment oynasida bemor ismini yozish bilan mos bemorlar ro‘yxati chiqadi. Mavjud bemorni tanlash yoki yangi ism kiritib bemor yozuvini yaratish mumkin.
- Shifokor va bemorlarni qo‘shish, tahrirlash hamda o‘chirish amallari backend API orqali bazaga saqlanadi.
- Dashboarddagi namuna sifatidagi bemor/shifokorlar va sun’iy grafik qiymatlari olib tashlangan. Grafik joriy haftadagi haqiqiy uchrashuvlar soniga qarab chiziladi.
- Light/Dark mode kontrasti yaxshilandi.

### Oldingi demo ma’lumotlarini bir marta tozalash

Agar MongoDB bazasida oldingi demo yozuvlari allaqachon saqlangan bo‘lsa, `.env` sozlangandan keyin loyiha ildizida quyidagini **bir marta** bajaring:

```bash
npm run clean-demo
```

Bu buyruq faqat `backend/src/cleanDemoData.js` ichida sanab o‘tilgan demo email manzillariga mos shifokor/bemorlar va ularga tegishli uchrashuvlarni o‘chiradi. Boshqa yozuvlar o‘chirilmaydi. Bazada demo ma’lumotlar bo‘lmasa, bu buyruq shart emas.
