# MedCare Frontend - fixed

1. Open this folder in VS Code.
2. Run: npm install
3. Make sure backend is running on http://localhost:5000
4. Run: npm run dev

Admin login:
Email: admin@medcare.com
Password: admin123

Fixes included:
- Restored/organized dashboard styling.
- Fixed Login import path.
- Made top-right profile/avatar clickable for logout.
- Kept existing doctor/patient/department CRUD.
- Fixed appointments to use patient/doctor IDs for the backend and display populated references safely.
- Added responsive layout and modal/table styling.
