import { askConfirm } from "./confirm";
import Ico from "./Icons";
import { useEffect, useState } from "react";

import {
  getDepartments,
  createDepartment,
  updateDepartment,
  deleteDepartment,
} from "./services/api";

export default function Department({ globalSearch = "" }) {

  const [departments, setDepartments] =
    useState([]);

  const [loading, setLoading] =
    useState(true);

  const [saving, setSaving] =
    useState(false);

  const [error, setError] =
    useState("");

  const [search, setSearch] =
    useState("");

  useEffect(() => { setSearch(globalSearch); }, [globalSearch]);

  const [showModal, setShowModal] =
    useState(false);

  const [editingDepartment, setEditingDepartment] =
    useState(null);

  const [form, setForm] = useState({
    name: "",
    description: "",
    head: "",
  });


  // ==========================================
  // LOAD
  // ==========================================

  async function loadDepartments() {
    try {
      setLoading(true);
      setError("");

      const data =
        await getDepartments();

      if (Array.isArray(data)) {
        setDepartments(data);
      } else if (
        Array.isArray(
          data?.departments
        )
      ) {
        setDepartments(
          data.departments
        );
      } else {
        setDepartments([]);
      }

    } catch (err) {
      setError(
        err.message ||
          "Departmentlarni olishda xatolik"
      );
    } finally {
      setLoading(false);
    }
  }


  useEffect(() => {
    loadDepartments();
  }, []);


  // ==========================================
  // CHANGE
  // ==========================================

  function handleChange(e) {
    const { name, value } = e.target;

    setForm((prev) => ({
      ...prev,
      [name]: value,
    }));
  }


  // ==========================================
  // CREATE
  // ==========================================

  function openCreate() {
    setEditingDepartment(null);

    setForm({
      name: "",
      description: "",
      icon: "🏥",
      status: "Active",
    });

    setShowModal(true);
  }


  // ==========================================
  // EDIT
  // ==========================================

  function openEdit(department) {
    setEditingDepartment(
      department
    );

    setForm({
      name:
        department.name || "",
      description:
        department.description ||
        "",
      icon: department.icon || "🏥",
      status: department.status || "Active",
    });

    setShowModal(true);
  }


  // ==========================================
  // SAVE
  // ==========================================

  async function handleSubmit(e) {
    e.preventDefault();

    try {
      setSaving(true);
      setError("");

      if (editingDepartment) {

        await updateDepartment(
          editingDepartment._id ||
            editingDepartment.id,
          form
        );

      } else {

        await createDepartment(
          form
        );

      }

      setShowModal(false);

      setEditingDepartment(null);

      await loadDepartments();

    } catch (err) {
      setError(
        err.message ||
          "Departmentni saqlashda xatolik"
      );
    } finally {
      setSaving(false);
    }
  }


  // ==========================================
  // DELETE
  // ==========================================

  async function handleDelete(id) {
    const confirmed =
      await askConfirm({ title: "Bo'limni o'chirish", message: "Bu bo'lim o'chiriladi. Davom etasizmi?" });

    if (!confirmed) return;

    try {
      setError("");

      await deleteDepartment(id);

      await loadDepartments();

    } catch (err) {
      setError(
        err.message ||
          "Departmentni o'chirishda xatolik"
      );
    }
  }


  // ==========================================
  // FILTER
  // ==========================================

  const filteredDepartments =
    departments.filter(
      (department) => {

        const text =
          `${department.name || ""} ${
            department.description || ""
          } ${
            department.head || ""
          }`.toLowerCase();

        return text.includes(
          search.toLowerCase()
        );
      }
    );


  return (
    <section className="page-section">

      {/* HEADER */}

      <div className="page-header">

        <div>
          <div className="page-title-icon"><Ico name="hospital" size={24} /></div>

          <div>
            <h2>
              Departments
            </h2>

            <p>
              Manage hospital departments
            </p>
          </div>
        </div>

        <button
          className="primary-button"
          onClick={openCreate}
        >
          + Add Department
        </button>

      </div>


      {/* ERROR */}

      {error && (
        <div className="app-error">

          <span>!</span>

          {error}

          <button
            onClick={() =>
              setError("")
            }
          >
            ×
          </button>

        </div>
      )}


      {/* SEARCH */}

      <div className="table-toolbar">

        <div className="search-box">

          <span>⌕</span>

          <input
            type="text"
            placeholder="Search departments..."
            value={search}
            onChange={(e) =>
              setSearch(
                e.target.value
              )
            }
          />

        </div>

        <span className="result-count">
          {filteredDepartments.length} departments
        </span>

      </div>


      {/* TABLE */}

      <div className="table-card">

        {loading ? (

          <div className="loading-state">

            <div className="loading-spinner"></div>

            Loading departments...

          </div>

        ) : filteredDepartments.length ===
          0 ? (

          <div className="empty-state">

            <div className="empty-icon"><Ico name="hospital" size={34} /></div>

            <h3>
              No departments found
            </h3>

            <p>
              Add your first department.
            </p>

            <button
              className="primary-button"
              onClick={openCreate}
            >
              + Add Department
            </button>

          </div>

        ) : (

          <div className="department-grid">

            {filteredDepartments.map(
              (
                department,
                index
              ) => {

                const id =
                  department._id ||
                  department.id ||
                  index;

                return (

                  <div
                    className="department-card"
                    key={id}
                  >

                    <div className="department-top">

                      <div className="department-icon"><Ico name={/cardio/i.test(department.name) ? "heart" : "hospital"} size={24} /></div>

                      <div className="department-actions">

                        <button
                          className="icon-edit"
                          onClick={() =>
                            openEdit(
                              department
                            )
                          }
                        >
                          <Ico name="edit" size={16} />
                        </button>

                        <button
                          className="icon-delete"
                          onClick={() =>
                            handleDelete(
                              id
                            )
                          }
                        >
                          <Ico name="trash" size={16} />
                        </button>

                      </div>

                    </div>


                    <h3>
                      {department.name ||
                        "Department"}
                    </h3>


                    <p>
                      {department.description ||
                        "No description available."}
                    </p>


                    <div className="department-bottom">

                      <span>
                        Head
                      </span>

                      <strong>
                        {department.head ||
                          "Not assigned"}
                      </strong>

                    </div>

                  </div>

                );
              }
            )}

          </div>

        )}

      </div>


      {/* MODAL */}

      {showModal && (

        <div
          className="modal-overlay"
          onClick={() =>
            setShowModal(false)
          }
        >

          <div
            className="modal"
            onClick={(e) =>
              e.stopPropagation()
            }
          >

            <div className="modal-header">

              <div>

                <h2>
                  {editingDepartment
                    ? "Edit Department"
                    : "Add Department"}
                </h2>

                <p>
                  Enter department information
                </p>

              </div>

              <button
                className="modal-close"
                onClick={() =>
                  setShowModal(false)
                }
              >
                ×
              </button>

            </div>


            <form
              onSubmit={
                handleSubmit
              }
            >

              <div className="form-grid">

                <div className="form-group full-width">

                  <label>
                    Department name
                  </label>

                  <input
                    type="text"
                    name="name"
                    value={form.name}
                    onChange={
                      handleChange
                    }
                    placeholder="Cardiology"
                    required
                  />

                </div>


                <div className="form-group full-width">

                  <label>
                    Description
                  </label>

                  <textarea
                    name="description"
                    value={
                      form.description
                    }
                    onChange={
                      handleChange
                    }
                    placeholder="Department description..."
                    rows="4"
                  />

                </div>


                <div className="form-group full-width">

                  <label>
                    Department head
                  </label>

                  <input
                    type="text"
                    name="head"
                    value={form.head}
                    onChange={
                      handleChange
                    }
                    placeholder="Dr. John Smith"
                  />

                </div>

              </div>


              <div className="modal-footer">

                <button
                  type="button"
                  className="cancel-button"
                  onClick={() =>
                    setShowModal(false)
                  }
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  className="primary-button"
                  disabled={saving}
                >
                  {saving
                    ? "Saving..."
                    : editingDepartment
                    ? "Update Department"
                    : "Add Department"}
                </button>

              </div>

            </form>

          </div>

        </div>

      )}

    </section>
  );
}