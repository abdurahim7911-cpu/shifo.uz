import { createRoot } from "react-dom/client";
import { useState } from "react";

function Dialog({ opts, done }) {
  const [busy, setBusy] = useState(false);
  const danger = opts.danger !== false;
  return (
    <div className="confirm-overlay" onClick={() => done(false)} role="presentation">
      <div className="confirm-box" role="alertdialog" aria-modal="true" aria-labelledby="confirm-title" onClick={(e) => e.stopPropagation()}>
        <div className={`confirm-icon ${danger ? "danger" : ""}`}>
          <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round"><path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3" /></svg>
        </div>
        <h3 id="confirm-title">{opts.title || "Are you sure?"}</h3>
        <p>{opts.message}</p>
        <div className="confirm-actions">
          <button type="button" className="cancel-button" autoFocus onClick={() => done(false)}>{opts.cancelText || "Cancel"}</button>
          <button type="button" className="confirm-ok" disabled={busy} onClick={() => { setBusy(true); done(true); }}>{opts.okText || "Delete"}</button>
        </div>
      </div>
    </div>
  );
}

export function askConfirm(input) {
  const opts = typeof input === "string" ? { message: input } : input || {};
  return new Promise((resolve) => {
    const host = document.createElement("div");
    document.body.appendChild(host);
    const root = createRoot(host);
    const onKey = (e) => { if (e.key === "Escape") done(false); };
    function done(value) {
      document.removeEventListener("keydown", onKey);
      root.unmount();
      host.remove();
      resolve(value);
    }
    document.addEventListener("keydown", onKey);
    root.render(<Dialog opts={opts} done={done} />);
  });
}
