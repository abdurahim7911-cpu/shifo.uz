import { askConfirm } from "./confirm";
import Ico from "./Icons";
import { useEffect, useState } from "react";

import {
  getPatients,
  createPatient,
  updatePatient,
  deletePatient,
} from "./services/api";

export default function Patient({ globalSearch = "" }) {
  const [patients, setPatients] = useState([]);

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const [error, setError] = useState("");

  const [search, setSearch] = useState("");

  useEffect(() => { setSearch(globalSearch); }, [globalSearch]);

  const [showModal, setShowModal] = useState(false);

  const [editingPatient, setEditingPatient] =
    useState(null);

  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    age: "",
    gender: "",
    address: "",
  });

  // ==========================================
  // LOAD
  // ==========================================

  async function loadPatients() {
    try {
      setLoading(true);
      setError("");

      const data = await getPatients();

      if (Array.isArray(data)) {
        setPatients(data);
      } else if (Array.isArray(data?.patients)) {
        setPatients(data.patients);
      } else {
        setPatients([]);
      }
    } catch (err) {
      setError(
        err.message ||
          "Patientlarni olishda xatolik"
      );
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadPatients();
  }, []);

  // ==========================================
  // CHANGE
  // ==========================================

  function handleChange(e) {
    const { name, value } = e.target;

    setForm((prev) => ({
      ...prev,
      [name]: value,
    }));
  }

  // ==========================================
  // OPEN CREATE
  // ==========================================

  function openCreate() {
    setEditingPatient(null);

    setForm({
      name: "",
      email: "",
      phone: "",
      age: "",
      gender: "",
      address: "",
    });

    setShowModal(true);
  }

  // ==========================================
  // OPEN EDIT
  // ==========================================

  function openEdit(patient) {
    setEditingPatient(patient);

    setForm({
      name: patient.name || "",
      email: patient.email || "",
      phone: patient.phone || "",
      age: patient.age || "",
      gender: patient.gender || "",
      address: patient.address || "",
    });

    setShowModal(true);
  }

  // ==========================================
  // SAVE
  // ==========================================

  async function handleSubmit(e) {
    e.preventDefault();

    try {
      setSaving(true);
      setError("");

      if (editingPatient) {
        await updatePatient(
          editingPatient._id ||
            editingPatient.id,
          form
        );
      } else {
        await createPatient(form);
      }

      setShowModal(false);

      setEditingPatient(null);

      await loadPatients();
    } catch (err) {
      setError(
        err.message ||
          "Patientni saqlashda xatolik"
      );
    } finally {
      setSaving(false);
    }
  }

  // ==========================================
  // DELETE
  // ==========================================

  async function handleDelete(id) {
    const confirmed = await askConfirm({ title: "Bemorni o'chirish", message: "Bu bemor va uning barcha uchrashuvlari o'chiriladi. Davom etasizmi?" });

    if (!confirmed) return;

    try {
      setError("");

      await deletePatient(id);

      await loadPatients();
    } catch (err) {
      setError(
        err.message ||
          "Patientni o'chirishda xatolik"
      );
    }
  }

  // ==========================================
  // FILTER
  // ==========================================

  const filteredPatients = patients.filter(
    (patient) => {
      const text =
        `${patient.name || ""} ${
          patient.email || ""
        } ${
          patient.phone || ""
        } ${
          patient.gender || ""
        } ${
          patient.address || ""
        }`.toLowerCase();

      return text.includes(
        search.toLowerCase()
      );
    }
  );

  // ==========================================
  // RENDER
  // ==========================================

  return (
    <section className="page-section">

      {/* HEADER */}

      <div className="page-header">

        <div>
          <div className="page-title-icon"><Ico name="users" size={24} /></div>

          <div>
            <h2>Patients</h2>

            <p>
              Manage hospital patients and
              their information
            </p>
          </div>
        </div>

        <button
          className="primary-button"
          onClick={openCreate}
        >
          + Add Patient
        </button>

      </div>


      {/* ERROR */}

      {error && (
        <div className="app-error">
          <span>!</span>

          {error}

          <button
            onClick={() => setError("")}
          >
            ×
          </button>
        </div>
      )}


      {/* SEARCH */}

      <div className="table-toolbar">

        <div className="search-box">

          <span>⌕</span>

          <input
            type="text"
            placeholder="Search patients..."
            value={search}
            onChange={(e) =>
              setSearch(e.target.value)
            }
          />

        </div>

        <span className="result-count">
          {filteredPatients.length} patients
        </span>

      </div>


      {/* TABLE */}

      <div className="table-card">

        {loading ? (

          <div className="loading-state">
            <div className="loading-spinner"></div>
            Loading patients...
          </div>

        ) : filteredPatients.length === 0 ? (

          <div className="empty-state">

            <div className="empty-icon"><Ico name="users" size={34} /></div>

            <h3>
              No patients found
            </h3>

            <p>
              Add your first patient to
              get started.
            </p>

            <button
              className="primary-button"
              onClick={openCreate}
            >
              + Add Patient
            </button>

          </div>

        ) : (

          <div className="table-wrapper">

            <table className="tbl-patients">

              <thead>
                <tr>

                  <th>
                    Patient
                  </th>

                  <th>
                    Email
                  </th>

                  <th>
                    Phone
                  </th>

                  <th>
                    Age
                  </th>

                  <th>
                    Gender
                  </th>

                  <th>
                    Address
                  </th>

                  <th>
                    Actions
                  </th>

                </tr>
              </thead>

              <tbody>

                {filteredPatients.map(
                  (patient, index) => {

                    const id =
                      patient._id ||
                      patient.id ||
                      index;

                    return (
                      <tr key={id}>

                        <td>

                          <div className="table-person">

                            <div className="person-avatar patient-avatar">
                              {(
                                patient.name ||
                                "P"
                              )
                                .charAt(0)
                                .toUpperCase()}
                            </div>

                            <strong>
                              {patient.name ||
                                "Unknown"}
                            </strong>

                          </div>

                        </td>

                        <td>
                          {patient.email ||
                            "-"}
                        </td>

                        <td>
                          {patient.phone ||
                            "-"}
                        </td>

                        <td>
                          {patient.age ||
                            "-"}
                        </td>

                        <td>
                          {patient.gender ||
                            "-"}
                        </td>

                        <td>
                          {patient.address ||
                            "-"}
                        </td>

                        <td>

                          <div className="table-actions">

                            <button
                              className="edit-button"
                              onClick={() =>
                                openEdit(
                                  patient
                                )
                              }
                            >
                              Edit
                            </button>

                            <button
                              className="delete-button"
                              onClick={() =>
                                handleDelete(
                                  id
                                )
                              }
                            >
                              Delete
                            </button>

                          </div>

                        </td>

                      </tr>
                    );
                  }
                )}

              </tbody>

            </table>

          </div>

        )}

      </div>


      {/* MODAL */}

      {showModal && (

        <div
          className="modal-overlay"
          onClick={() =>
            setShowModal(false)
          }
        >

          <div
            className="modal"
            onClick={(e) =>
              e.stopPropagation()
            }
          >

            <div className="modal-header">

              <div>
                <h2>
                  {editingPatient
                    ? "Edit Patient"
                    : "Add Patient"}
                </h2>

                <p>
                  Enter patient information
                </p>
              </div>

              <button
                className="modal-close"
                onClick={() =>
                  setShowModal(false)
                }
              >
                ×
              </button>

            </div>


            <form onSubmit={handleSubmit}>

              <div className="form-grid">

                <div className="form-group">

                  <label>
                    Full name
                  </label>

                  <input
                    type="text"
                    name="name"
                    value={form.name}
                    onChange={handleChange}
                    placeholder="John Smith"
                    required
                  />

                </div>


                <div className="form-group">

                  <label>
                    Email
                  </label>

                  <input
                    type="email"
                    name="email"
                    value={form.email}
                    onChange={handleChange}
                    placeholder="patient@example.com"
                  />

                </div>


                <div className="form-group">

                  <label>
                    Phone
                  </label>

                  <input
                    type="text"
                    name="phone"
                    value={form.phone}
                    onChange={handleChange}
                    placeholder="+998 90 123 45 67"
                  />

                </div>


                <div className="form-group">

                  <label>
                    Age
                  </label>

                  <input
                    type="number"
                    name="age"
                    value={form.age}
                    onChange={handleChange}
                    placeholder="25"
                    min="0"
                  />

                </div>


                <div className="form-group">

                  <label>
                    Gender
                  </label>

                  <select
                    name="gender"
                    value={form.gender}
                    onChange={handleChange}
                  >
                    <option value="">
                      Select gender
                    </option>

                    <option value="Male">
                      Male
                    </option>

                    <option value="Female">
                      Female
                    </option>
                  </select>

                </div>


                <div className="form-group">

                  <label>
                    Address
                  </label>

                  <input
                    type="text"
                    name="address"
                    value={form.address}
                    onChange={handleChange}
                    placeholder="Tashkent, Uzbekistan"
                  />

                </div>

              </div>


              <div className="modal-footer">

                <button
                  type="button"
                  className="cancel-button"
                  onClick={() =>
                    setShowModal(false)
                  }
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  className="primary-button"
                  disabled={saving}
                >
                  {saving
                    ? "Saving..."
                    : editingPatient
                    ? "Update Patient"
                    : "Add Patient"}
                </button>

              </div>

            </form>

          </div>

        </div>

      )}

    </section>
  );
}