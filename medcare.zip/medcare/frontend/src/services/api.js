// Developmentda /api Vite proxy orqali http://127.0.0.1:5000 ga boradi.
// Productionda frontend backendning o'zidan berilsa ham /api shu origin orqali ishlaydi.
const API_URL = (import.meta.env.VITE_API_URL || "/api").replace(/\/$/, "");

const REQUEST_TIMEOUT = 8000;

async function request(path, options = {}) {
  let response;
  let controller;
  let timeout;
  try {
    controller = new AbortController();
    timeout = setTimeout(() => controller.abort(), REQUEST_TIMEOUT);
    response = await fetch(`${API_URL}${path}`, {
      headers: { "Content-Type": "application/json", ...(options.headers || {}) },
      ...options,
      signal: options.signal || controller.signal,
    });
  } catch (error) {
    if (error?.name === "AbortError") {
      throw new Error("Backend javob bermayapti. npm run dev ishlayotganini tekshiring.");
    }
    throw new Error("Backendga ulanib bo'lmadi. npm run dev bilan ikkala serverni birga ishga tushiring.");
  } finally {
    if (timeout) clearTimeout(timeout);
  }

  let data = null;
  try { data = await response.json(); } catch { data = {}; }
  if (!response.ok) throw new Error(data?.message || "So'rovni bajarishda xatolik");
  return data;
}

export const loginUser = (email, password) => request("/auth/login", { method: "POST", body: JSON.stringify({ email: email.toLowerCase(), password }) });
export const registerUser = (name, email, password) => request("/auth/register", { method: "POST", body: JSON.stringify({ name, email: email.toLowerCase(), password }) });
export const forgotPassword = (email) => request("/auth/forgot-password", { method: "POST", body: JSON.stringify({ email: email.toLowerCase() }) });
export const resetPassword = (email, code, newPassword) => request("/auth/reset-password", { method: "POST", body: JSON.stringify({ email: email.toLowerCase(), code, newPassword }) });
export const getDashboardStats = () => request("/dashboard/stats");
export const getDoctors = (q = "") => request(`/doctors${q ? `?q=${encodeURIComponent(q)}` : ""}`);
export const getDoctorById = (id) => request(`/doctors/${id}`);
export const createDoctor = (doctor) => request("/doctors", { method: "POST", body: JSON.stringify(doctor) });
export const updateDoctor = (id, doctor) => request(`/doctors/${id}`, { method: "PUT", body: JSON.stringify(doctor) });
export const deleteDoctor = (id) => request(`/doctors/${id}`, { method: "DELETE" });
export const getPatients = (q = "") => request(`/patients${q ? `?q=${encodeURIComponent(q)}` : ""}`);
export const getPatientById = (id) => request(`/patients/${id}`);
export const createPatient = (patient) => request("/patients", { method: "POST", body: JSON.stringify(patient) });
export const updatePatient = (id, patient) => request(`/patients/${id}`, { method: "PUT", body: JSON.stringify(patient) });
export const deletePatient = (id) => request(`/patients/${id}`, { method: "DELETE" });
export const getAppointments = () => request("/appointments");
export const getAppointmentById = (id) => request(`/appointments/${id}`);
export const createAppointment = (appointment) => request("/appointments", { method: "POST", body: JSON.stringify(appointment) });
export const updateAppointment = (id, appointment) => request(`/appointments/${id}`, { method: "PUT", body: JSON.stringify(appointment) });
export const deleteAppointment = (id) => request(`/appointments/${id}`, { method: "DELETE" });
export const getDepartments = (q = "") => request(`/departments${q ? `?q=${encodeURIComponent(q)}` : ""}`);
export const getDepartmentById = (id) => request(`/departments/${id}`);
export const createDepartment = (department) => request("/departments", { method: "POST", body: JSON.stringify(department) });
export const updateDepartment = (id, department) => request(`/departments/${id}`, { method: "PUT", body: JSON.stringify(department) });
export const deleteDepartment = (id) => request(`/departments/${id}`, { method: "DELETE" });
export const getProfile = (id) => request(`/auth/profile/${id}`);
export const updateProfile = (id, profile) => request(`/auth/profile/${id}`, { method: "PUT", body: JSON.stringify(profile) });
export const createSupportTicket = (ticket) => request("/support/tickets", { method: "POST", body: JSON.stringify(ticket) });
