import { askConfirm } from "./confirm";
import Ico from "./Icons";
import { useEffect, useState } from "react";
import {
  getAppointments,
  createAppointment,
  updateAppointment,
  deleteAppointment,
  getDoctors,
  getPatients,
  createPatient,
} from "./services/api";

const emptyForm = {
  patient: "",
  doctor: "",
  date: "",
  time: "",
  reason: "",
  status: "Scheduled",
};

function getId(item) {
  return item?._id || item?.id || "";
}

function getName(value, fallback = "Unknown") {
  if (!value) return fallback;
  if (typeof value === "string") return value;
  return value.name || fallback;
}

function dateValue(value) {
  if (!value) return "";
  if (typeof value === "string" && /^\d{4}-\d{2}-\d{2}$/.test(value)) return value;
  const d = new Date(value);
  return Number.isNaN(d.getTime()) ? String(value).slice(0, 10) : d.toISOString().slice(0, 10);
}

export default function Appointment({ globalSearch = "" }) {
  const [appointments, setAppointments] = useState([]);
  const [doctors, setDoctors] = useState([]);
  const [patients, setPatients] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [search, setSearch] = useState("");

  useEffect(() => { setSearch(globalSearch); }, [globalSearch]);
  const [showModal, setShowModal] = useState(false);
  const [editingAppointment, setEditingAppointment] = useState(null);
  const [form, setForm] = useState(emptyForm);
  const [patientName, setPatientName] = useState("");
  const [patientSuggestionsOpen, setPatientSuggestionsOpen] = useState(false);

  async function loadData() {
    try {
      setLoading(true);
      setError("");
      const [appointmentsData, doctorsData, patientsData] = await Promise.all([
        getAppointments(),
        getDoctors(),
        getPatients(),
      ]);

      setAppointments(Array.isArray(appointmentsData) ? appointmentsData : appointmentsData?.appointments || []);
      setDoctors(Array.isArray(doctorsData) ? doctorsData : doctorsData?.doctors || []);
      setPatients(Array.isArray(patientsData) ? patientsData : patientsData?.patients || []);
    } catch (err) {
      setError(err.message || "Ma'lumotlarni olishda xatolik");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadData();
  }, []);

  function handleChange(e) {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  }

  function openCreate() {
    setEditingAppointment(null);
    setForm({ ...emptyForm });
    setPatientName("");
    setPatientSuggestionsOpen(false);
    setShowModal(true);
  }

  function openEdit(appointment) {
    setEditingAppointment(appointment);
    setForm({
      patient: getId(appointment.patient) || appointment.patientId || "",
      doctor: getId(appointment.doctor) || appointment.doctorId || "",
      date: dateValue(appointment.date || appointment.appointmentDate),
      time: appointment.time || "",
      reason: appointment.reason || "",
      status: appointment.status || "Scheduled",
    });
    setPatientName(getName(appointment.patient, appointment.patientName || ""));
    setPatientSuggestionsOpen(false);
    setShowModal(true);
  }

  async function handleSubmit(e) {
    e.preventDefault();
    try {
      setSaving(true);
      setError("");

      let patientId = form.patient;
      if (!patientId && patientName.trim()) {
        const exactMatch = patients.find((patient) => patient.name?.trim().toLowerCase() === patientName.trim().toLowerCase());
        if (exactMatch) {
          patientId = getId(exactMatch);
        } else {
          const createdPatient = await createPatient({ name: patientName.trim(), status: "Active" });
          patientId = getId(createdPatient);
          setPatients((prev) => [createdPatient, ...prev]);
        }
      }
      if (!patientId) throw new Error("Bemor ismini yozing va ro‘yxatdan tanlang yoki yangi ism kiriting.");

      const payload = {
        patient: patientId,
        doctor: form.doctor,
        date: form.date,
        time: form.time,
        reason: form.reason,
        status: form.status,
      };

      if (editingAppointment) {
        await updateAppointment(getId(editingAppointment), payload);
      } else {
        await createAppointment(payload);
      }

      setShowModal(false);
      setEditingAppointment(null);
      setForm({ ...emptyForm });
      setPatientName("");
      setPatientSuggestionsOpen(false);
      await loadData();
    } catch (err) {
      setError(err.message || "Appointmentni saqlashda xatolik");
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(id) {
    if (!id || !(await askConfirm({ title: "Uchrashuvni o'chirish", message: "Bu uchrashuv o'chiriladi. Davom etasizmi?" }))) return;
    try {
      setError("");
      await deleteAppointment(id);
      await loadData();
    } catch (err) {
      setError(err.message || "Appointmentni o'chirishda xatolik");
    }
  }

  const filteredAppointments = appointments.filter((appointment) => {
    const patient = getName(appointment.patient, appointment.patientName);
    const doctor = getName(appointment.doctor, appointment.doctorName);
    const text = `${patient} ${doctor} ${appointment.reason || ""} ${appointment.status || ""} ${appointment.date || ""}`.toLowerCase();
    return text.includes(search.toLowerCase());
  });

  function statusClass(status) {
    const value = String(status || "Scheduled").toLowerCase();
    if (value === "completed") return "status-completed";
    if (value === "cancelled" || value === "canceled") return "status-cancelled";
    if (value === "pending") return "status-pending";
    return "status-scheduled";
  }

  return (
    <section className="page-section">
      <div className="page-header">
        <div>
          <div className="page-title-icon"><Ico name="calendar" size={24} /></div>
          <div>
            <h2>Appointments</h2>
            <p>Manage hospital appointments</p>
          </div>
        </div>
        <button className="primary-button" onClick={openCreate}>+ New Appointment</button>
      </div>

      {error && (
        <div className="app-error">
          <span>!</span>
          {error}
          <button onClick={() => setError("")}>×</button>
        </div>
      )}

      <div className="table-toolbar">
        <div className="search-box">
          <span>⌕</span>
          <input
            type="text"
            placeholder="Search appointments..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <span className="result-count">{filteredAppointments.length} appointments</span>
      </div>

      <div className="table-card">
        {loading ? (
          <div className="loading-state">
            <div className="loading-spinner" />
            Loading appointments...
          </div>
        ) : filteredAppointments.length === 0 ? (
          <div className="empty-state">
            <div className="empty-icon"><Ico name="calendar" size={34} /></div>
            <h3>No appointments found</h3>
            <p>Create your first appointment.</p>
            <button className="primary-button" onClick={openCreate}>+ New Appointment</button>
          </div>
        ) : (
          <div className="table-wrapper">
            <table className="tbl-appts">
              <thead>
                <tr>
                  <th>Patient</th><th>Doctor</th><th>Date</th><th>Time</th>
                  <th>Reason</th><th>Status</th><th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredAppointments.map((appointment, index) => {
                  const id = getId(appointment) || index;
                  const patient = getName(appointment.patient, appointment.patientName || "Patient");
                  const doctor = getName(appointment.doctor, appointment.doctorName || "Doctor");
                  return (
                    <tr key={id}>
                      <td>
                        <div className="table-person">
                          <div className="person-avatar">{patient.charAt(0).toUpperCase()}</div>
                          <strong>{patient}</strong>
                        </div>
                      </td>
                      <td>{doctor}</td>
                      <td>{dateValue(appointment.date || appointment.appointmentDate) || "-"}</td>
                      <td>{appointment.time || "-"}</td>
                      <td>{appointment.reason || "-"}</td>
                      <td><span className={`status-badge ${statusClass(appointment.status)}`}>{appointment.status || "Scheduled"}</span></td>
                      <td>
                        <div className="table-actions">
                          <button className="edit-button" onClick={() => openEdit(appointment)}>Edit</button>
                          <button className="delete-button" onClick={() => handleDelete(id)}>Delete</button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {showModal && (
        <div className="modal-overlay" onClick={() => { setShowModal(false); setPatientSuggestionsOpen(false); }}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <div>
                <h2>{editingAppointment ? "Edit Appointment" : "New Appointment"}</h2>
                <p>Schedule a hospital appointment</p>
              </div>
              <button type="button" className="modal-close" aria-label="Close appointment form" onClick={() => { setShowModal(false); setPatientSuggestionsOpen(false); }}>×</button>
            </div>

            <form onSubmit={handleSubmit}>
              <div className="form-grid">
                <div className="form-group patient-autocomplete">
                  <label htmlFor="appointment-patient-name">Patient name</label>
                  <input
                    id="appointment-patient-name"
                    type="text"
                    autoComplete="off"
                    value={patientName}
                    onFocus={() => setPatientSuggestionsOpen(true)}
                    onChange={(event) => {
                      const value = event.target.value;
                      setPatientName(value);
                      setPatientSuggestionsOpen(true);
                      const exact = patients.find((patient) => patient.name?.trim().toLowerCase() === value.trim().toLowerCase());
                      setForm((prev) => ({ ...prev, patient: exact ? getId(exact) : "" }));
                    }}
                    placeholder="Bemor ismini yozing..."
                    required
                  />
                  {patientSuggestionsOpen && patientName.trim() && (
                    <div className="patient-suggestions" role="listbox" aria-label="Mos bemorlar">
                      {patients.filter((patient) => patient.name?.toLowerCase().includes(patientName.trim().toLowerCase())).slice(0, 6).map((patient) => (
                        <button key={getId(patient)} type="button" role="option" onClick={() => {
                          setPatientName(patient.name || "");
                          setForm((prev) => ({ ...prev, patient: getId(patient) }));
                          setPatientSuggestionsOpen(false);
                        }}>
                          <span className="suggestion-avatar">{(patient.name || "P").charAt(0).toUpperCase()}</span>
                          <span><strong>{patient.name}</strong><small>{patient.phone || patient.email || "Bemor"}</small></span>
                        </button>
                      ))}
                      {!patients.some((patient) => patient.name?.toLowerCase() === patientName.trim().toLowerCase()) && (
                        <div className="suggestion-new">+ “{patientName.trim()}” yangi bemor sifatida qo‘shiladi</div>
                      )}
                    </div>
                  )}
                  <small className="field-hint">Ismni yozing, mos bemorni tanlang yoki yangi bemor ismini kiriting.</small>
                </div>

                <div className="form-group">
                  <label>Doctor</label>
                  <select name="doctor" value={form.doctor} onChange={handleChange} required>
                    <option value="">Select doctor</option>
                    {doctors.map((doctor) => (
                      <option key={getId(doctor)} value={getId(doctor)}>{doctor.name || "Unnamed doctor"}</option>
                    ))}
                  </select>
                </div>

                <div className="form-group">
                  <label>Date</label>
                  <input type="date" name="date" value={form.date} onChange={handleChange} required />
                </div>

                <div className="form-group">
                  <label>Time</label>
                  <input type="time" name="time" value={form.time} onChange={handleChange} required />
                </div>

                <div className="form-group">
                  <label>Status</label>
                  <select name="status" value={form.status} onChange={handleChange}>
                    <option value="Scheduled">Scheduled</option>
                    <option value="Pending">Pending</option>
                    <option value="Completed">Completed</option>
                    <option value="Cancelled">Cancelled</option>
                  </select>
                </div>

                <div className="form-group full-width">
                  <label>Reason</label>
                  <input type="text" name="reason" value={form.reason} onChange={handleChange} placeholder="Regular check-up" />
                </div>
              </div>

              <div className="modal-footer">
                <button type="button" className="cancel-button" onClick={() => setShowModal(false)}>Cancel</button>
                <button type="submit" className="primary-button" disabled={saving}>
                  {saving ? "Saving..." : editingAppointment ? "Update Appointment" : "Create Appointment"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </section>
  );
}
