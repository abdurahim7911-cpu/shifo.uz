const P = {
  hospital: <><path d="M4 21V5a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v16" /><path d="M2 21h20M8 7h4M10 5v4M7 12h2M12 12h2M7 16h2M12 16h2M16 9h2a2 2 0 0 1 2 2v10" /></>,
  heart: <path d="M12 20s-7.5-4.6-9-9.5C2 7 4.5 4.5 7.5 4.5c1.9 0 3.4 1 4.5 2.6 1.1-1.6 2.6-2.6 4.5-2.6 3 0 5.5 2.5 4.5 6C19.5 15.4 12 20 12 20z" />,
  calendar: <><rect x="3" y="5" width="18" height="16" rx="2" /><path d="M16 3v4M8 3v4M3 10h18" /></>,
  users: <><circle cx="9" cy="8" r="3" /><path d="M3.5 20c.5-3.7 2.4-5.5 5.5-5.5s5 1.8 5.5 5.5" /><path d="M16 5.5a3 3 0 0 1 0 5.7M17 14.7c2.2.4 3.5 2 4 5.3" /></>,
  doctor: <><circle cx="12" cy="7" r="3.2" /><path d="M5 21c.6-4 3-6 7-6s6.4 2 7 6" /><path d="M17.5 11.5v3M16 13h3" /></>,
  edit: <path d="m4 20 4.5-1 9.8-9.8a2.1 2.1 0 0 0-3-3L5.5 16zM13.5 7.5l3 3" />,
  clock: <><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" /></>,
  check: <path d="m5 12 4 4L19 6" />,
  close: <path d="m6 6 12 12M18 6 6 18" />,
  trash: <path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3" />,
  hourglass: <path d="M6 3h12M6 21h12M7 3c0 5 5 5 5 9s-5 4-5 9M17 3c0 5-5 5-5 9s5 4 5 9" />,
};
export default function Ico({ name, size = 18, stroke = 1.8 }) {
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{P[name]}</svg>;
}
