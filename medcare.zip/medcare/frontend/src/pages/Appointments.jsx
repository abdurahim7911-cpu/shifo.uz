import { useEffect, useState } from "react";

import {
  getAppointments,
  createAppointment,
  updateAppointment,
  deleteAppointment,
  getPatients,
  getDoctors,
} from "./services/api";

export default function Appointment() {
  const [appointments, setAppointments] = useState([]);
  const [patients, setPatients] = useState([]);
  const [doctors, setDoctors] = useState([]);

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("All");

  const [showModal, setShowModal] = useState(false);
  const [showEditModal, setShowEditModal] =
    useState(false);

  const [editingAppointment, setEditingAppointment] =
    useState(null);

  const emptyForm = {
    patient: "",
    doctor: "",
    date: "",
    time: "",
    reason: "",
    status: "Scheduled",
  };

  const [form, setForm] = useState(emptyForm);

  // =========================
  // LOAD DATA
  // =========================

  useEffect(() => {
    loadData();
  }, []);

  async function loadData() {
    try {
      setLoading(true);
      setError("");

      const [
        appointmentsData,
        patientsData,
        doctorsData,
      ] = await Promise.all([
        getAppointments(),
        getPatients(),
        getDoctors(),
      ]);

      setAppointments(appointmentsData);
      setPatients(patientsData);
      setDoctors(doctorsData);
    } catch (err) {
      console.error(err);

      setError(
        "Appointment ma'lumotlarini yuklashda xatolik"
      );
    } finally {
      setLoading(false);
    }
  }

  // =========================
  // FORM CHANGE
  // =========================

  function handleChange(e) {
    setForm({
      ...form,
      [e.target.name]: e.target.value,
    });
  }

  // =========================
  // SEARCH + FILTER
  // =========================

  const filteredAppointments =
    appointments.filter((appointment) => {
      const patientName =
        appointment.patient?.name || "";

      const doctorName =
        appointment.doctor?.name || "";

      const reason =
        appointment.reason || "";

      const searchText = `
        ${patientName}
        ${doctorName}
        ${reason}
        ${appointment.date || ""}
        ${appointment.time || ""}
      `.toLowerCase();

      const matchesSearch =
        searchText.includes(
          search.toLowerCase()
        );

      const matchesStatus =
        statusFilter === "All" ||
        appointment.status === statusFilter;

      return (
        matchesSearch &&
        matchesStatus
      );
    });

  // =========================
  // ADD APPOINTMENT
  // =========================

  async function handleSubmit(e) {
    e.preventDefault();

    try {
      setError("");

      const newAppointment =
        await createAppointment({
          patient: form.patient,
          doctor: form.doctor,
          date: form.date,
          time: form.time,
          reason: form.reason,
          status: form.status,
        });

      setAppointments((prev) => [
        newAppointment,
        ...prev,
      ]);

      setForm(emptyForm);
      setShowModal(false);
    } catch (err) {
      console.error(err);

      setError(
        "Appointment yaratishda xatolik"
      );
    }
  }

  // =========================
  // OPEN EDIT
  // =========================

  function handleEdit(appointment) {
    setEditingAppointment(appointment);

    setForm({
      patient:
        appointment.patient?._id || "",
      doctor:
        appointment.doctor?._id || "",
      date: appointment.date || "",
      time: appointment.time || "",
      reason: appointment.reason || "",
      status:
        appointment.status || "Scheduled",
    });

    setShowEditModal(true);
  }

  // =========================
  // UPDATE
  // =========================

  async function handleUpdate(e) {
    e.preventDefault();

    if (!editingAppointment) {
      return;
    }

    try {
      setError("");

      const updatedAppointment =
        await updateAppointment(
          editingAppointment._id,
          {
            patient: form.patient,
            doctor: form.doctor,
            date: form.date,
            time: form.time,
            reason: form.reason,
            status: form.status,
          }
        );

      setAppointments((prev) =>
        prev.map((appointment) =>
          appointment._id ===
          editingAppointment._id
            ? updatedAppointment
            : appointment
        )
      );

      setShowEditModal(false);
      setEditingAppointment(null);
      setForm(emptyForm);
    } catch (err) {
      console.error(err);

      setError(
        "Appointmentni yangilashda xatolik"
      );
    }
  }

  // =========================
  // DELETE
  // =========================

  async function handleDelete(id) {
    const confirmed = window.confirm(
      "Appointmentni o'chirishni xohlaysizmi?"
    );

    if (!confirmed) {
      return;
    }

    try {
      setError("");

      await deleteAppointment(id);

      setAppointments((prev) =>
        prev.filter(
          (appointment) =>
            appointment._id !== id
        )
      );
    } catch (err) {
      console.error(err);

      setError(
        "Appointmentni o'chirishda xatolik"
      );
    }
  }

  // =========================
  // MODALS
  // =========================

  function openAddModal() {
    setForm(emptyForm);
    setShowModal(true);
  }

  function closeAddModal() {
    setShowModal(false);
    setForm(emptyForm);
  }

  function closeEditModal() {
    setShowEditModal(false);
    setEditingAppointment(null);
    setForm(emptyForm);
  }

  // =========================
  // STATUS CLASS
  // =========================

  function getStatusClass(status) {
    if (status === "Completed") {
      return "completed-status";
    }

    if (status === "Cancelled") {
      return "cancelled-status";
    }

    return "scheduled-status";
  }

  return (
    <>
      {/* =========================
          HEADER
      ========================= */}

      <div className="header">
        <div>
          <h1>Appointments</h1>

          <p>
            Manage hospital appointments
          </p>
        </div>

        <div className="user">
          <div className="avatar">
            A
          </div>

          <div>
            <b>Admin</b>
            <small>Administrator</small>
          </div>
        </div>
      </div>

      {/* =========================
          TOOLBAR
      ========================= */}

      <div className="toolbar">
        <input
          type="text"
          placeholder="Search appointments..."
          value={search}
          onChange={(e) =>
            setSearch(e.target.value)
          }
        />

        <select
          value={statusFilter}
          onChange={(e) =>
            setStatusFilter(e.target.value)
          }
        >
          <option value="All">
            All Status
          </option>

          <option value="Scheduled">
            Scheduled
          </option>

          <option value="Completed">
            Completed
          </option>

          <option value="Cancelled">
            Cancelled
          </option>
        </select>

        <button onClick={openAddModal}>
          + Add Appointment
        </button>
      </div>

      {/* =========================
          ERROR
      ========================= */}

      {error && (
        <div className="error-message">
          {error}
        </div>
      )}

      {/* =========================
          TABLE
      ========================= */}

      <div className="table-box">
        {loading ? (
          <div className="loading-message">
            Appointmentlar yuklanmoqda...
          </div>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Patient</th>
                <th>Doctor</th>
                <th>Date</th>
                <th>Time</th>
                <th>Reason</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>

            <tbody>
              {filteredAppointments.map(
                (appointment) => (
                  <tr
                    key={
                      appointment._id
                    }
                  >
                    {/* PATIENT */}

                    <td>
                      <div className="doctor">
                        <div className="doctor-avatar">
                          {(
                            appointment.patient
                              ?.name || "P"
                          )
                            .charAt(0)
                            .toUpperCase()}
                        </div>

                        <div>
                          <b>
                            {appointment.patient
                              ?.name ||
                              "Unknown"}
                          </b>

                          <small>
                            {appointment.patient
                              ?.phone ||
                              ""}
                          </small>
                        </div>
                      </div>
                    </td>

                    {/* DOCTOR */}

                    <td>
                      <div>
                        <b>
                          {appointment.doctor
                            ?.name ||
                            "Unknown"}
                        </b>

                        <small>
                          {appointment.doctor
                            ?.specialty ||
                            ""}
                        </small>
                      </div>
                    </td>

                    {/* DATE */}

                    <td>
                      {appointment.date ||
                        "-"}
                    </td>

                    {/* TIME */}

                    <td>
                      {appointment.time ||
                        "-"}
                    </td>

                    {/* REASON */}

                    <td>
                      {appointment.reason ||
                        "-"}
                    </td>

                    {/* STATUS */}

                    <td>
                      <span
                        className={getStatusClass(
                          appointment.status
                        )}
                      >
                        {appointment.status}
                      </span>
                    </td>

                    {/* ACTION */}

                    <td>
                      <button
                        className="action"
                        onClick={() =>
                          handleEdit(
                            appointment
                          )
                        }
                      >
                        Edit
                      </button>

                      <button
                        className="delete"
                        onClick={() =>
                          handleDelete(
                            appointment._id
                          )
                        }
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                )
              )}

              {filteredAppointments.length ===
                0 && (
                <tr>
                  <td
                    colSpan="7"
                    className="empty-table"
                  >
                    Appointment topilmadi
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        )}
      </div>

      {/* =========================
          ADD MODAL
      ========================= */}

      {showModal && (
        <div
          className="modal-bg"
          onClick={closeAddModal}
        >
          <div
            className="modal"
            onClick={(e) =>
              e.stopPropagation()
            }
          >
            <h2>
              Add Appointment
            </h2>

            <form
              onSubmit={handleSubmit}
            >
              {/* PATIENT */}

              <label>
                Patient
              </label>

              <select
                name="patient"
                value={form.patient}
                onChange={handleChange}
                required
              >
                <option value="">
                  Select patient
                </option>

                {patients.map(
                  (patient) => (
                    <option
                      key={
                        patient._id
                      }
                      value={
                        patient._id
                      }
                    >
                      {patient.name}
                    </option>
                  )
                )}
              </select>

              {/* DOCTOR */}

              <label>
                Doctor
              </label>

              <select
                name="doctor"
                value={form.doctor}
                onChange={handleChange}
                required
              >
                <option value="">
                  Select doctor
                </option>

                {doctors.map(
                  (doctor) => (
                    <option
                      key={
                        doctor._id
                      }
                      value={
                        doctor._id
                      }
                    >
                      {doctor.name}
                      {doctor.specialty
                        ? ` - ${doctor.specialty}`
                        : ""}
                    </option>
                  )
                )}
              </select>

              {/* DATE */}

              <label>
                Date
              </label>

              <input
                type="date"
                name="date"
                value={form.date}
                onChange={handleChange}
                required
              />

              {/* TIME */}

              <label>
                Time
              </label>

              <input
                type="time"
                name="time"
                value={form.time}
                onChange={handleChange}
                required
              />

              {/* REASON */}

              <label>
                Reason
              </label>

              <input
                type="text"
                name="reason"
                placeholder="Reason for appointment"
                value={form.reason}
                onChange={handleChange}
              />

              {/* STATUS */}

              <label>
                Status
              </label>

              <select
                name="status"
                value={form.status}
                onChange={handleChange}
              >
                <option value="Scheduled">
                  Scheduled
                </option>

                <option value="Completed">
                  Completed
                </option>

                <option value="Cancelled">
                  Cancelled
                </option>
              </select>

              {/* BUTTONS */}

              <div className="modal-buttons">
                <button
                  type="button"
                  onClick={
                    closeAddModal
                  }
                >
                  Cancel
                </button>

                <button type="submit">
                  Add Appointment
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* =========================
          EDIT MODAL
      ========================= */}

      {showEditModal && (
        <div
          className="modal-bg"
          onClick={closeEditModal}
        >
          <div
            className="modal"
            onClick={(e) =>
              e.stopPropagation()
            }
          >
            <h2>
              Edit Appointment
            </h2>

            <form
              onSubmit={handleUpdate}
            >
              {/* PATIENT */}

              <label>
                Patient
              </label>

              <select
                name="patient"
                value={form.patient}
                onChange={handleChange}
                required
              >
                <option value="">
                  Select patient
                </option>

                {patients.map(
                  (patient) => (
                    <option
                      key={
                        patient._id
                      }
                      value={
                        patient._id
                      }
                    >
                      {patient.name}
                    </option>
                  )
                )}
              </select>

              {/* DOCTOR */}

              <label>
                Doctor
              </label>

              <select
                name="doctor"
                value={form.doctor}
                onChange={handleChange}
                required
              >
                <option value="">
                  Select doctor
                </option>

                {doctors.map(
                  (doctor) => (
                    <option
                      key={
                        doctor._id
                      }
                      value={
                        doctor._id
                      }
                    >
                      {doctor.name}
                      {doctor.specialty
                        ? ` - ${doctor.specialty}`
                        : ""}
                    </option>
                  )
                )}
              </select>

              {/* DATE */}

              <label>
                Date
              </label>

              <input
                type="date"
                name="date"
                value={form.date}
                onChange={handleChange}
                required
              />

              {/* TIME */}

              <label>
                Time
              </label>

              <input
                type="time"
                name="time"
                value={form.time}
                onChange={handleChange}
                required
              />

              {/* REASON */}

              <label>
                Reason
              </label>

              <input
                type="text"
                name="reason"
                placeholder="Reason for appointment"
                value={form.reason}
                onChange={handleChange}
              />

              {/* STATUS */}

              <label>
                Status
              </label>

              <select
                name="status"
                value={form.status}
                onChange={handleChange}
              >
                <option value="Scheduled">
                  Scheduled
                </option>

                <option value="Completed">
                  Completed
                </option>

                <option value="Cancelled">
                  Cancelled
                </option>
              </select>

              {/* BUTTONS */}

              <div className="modal-buttons">
                <button
                  type="button"
                  onClick={
                    closeEditModal
                  }
                >
                  Cancel
                </button>

                <button type="submit">
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </>
  );
}