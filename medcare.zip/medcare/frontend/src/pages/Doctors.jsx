import { useEffect, useState } from "react";

import {
  getDoctors,
  createDoctor,
  updateDoctor,
  deleteDoctor as deleteDoctorApi,
} from "../services/api";

export default function Doctors() {
  const [doctors, setDoctors] = useState([]);

  const [showModal, setShowModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);

  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const [editingDoctor, setEditingDoctor] = useState(null);

  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    specialty: "",
    department: "",
  });

  // =========================
  // DOCTORLARNI YUKLASH
  // =========================

  useEffect(() => {
    async function loadDoctors() {
      try {
        setLoading(true);
        setError("");

        const data = await getDoctors();

        setDoctors(data);
      } catch (err) {
        console.error(err);
        setError("Doctorlarni yuklashda xatolik");
      } finally {
        setLoading(false);
      }
    }

    loadDoctors();
  }, []);

  // =========================
  // SEARCH
  // =========================

  const filteredDoctors = doctors.filter((doctor) =>
    `${doctor.name} ${doctor.email} ${doctor.specialty}`
      .toLowerCase()
      .includes(search.toLowerCase()),
  );

  // =========================
  // FORM O'ZGARISHI
  // =========================

  function handleChange(e) {
    setForm({
      ...form,
      [e.target.name]: e.target.value,
    });
  }

  // =========================
  // ADD DOCTOR
  // =========================

  async function handleSubmit(e) {
    e.preventDefault();

    try {
      setError("");

      const newDoctor = await createDoctor({
        name: form.name,
        email: form.email,
        phone: form.phone,
        specialty: form.specialty,
        experience: 0,
        status: "Active",
      });

      setDoctors((prev) => [...prev, newDoctor]);

      setForm({
        name: "",
        email: "",
        phone: "",
        specialty: "",
        department: "",
      });

      setShowModal(false);
    } catch (err) {
      console.error(err);
      setError("Doctor yaratishda xatolik");
    }
  }

  // =========================
  // EDIT MODALNI OCHISH
  // =========================

  function handleEdit(doctor) {
    setEditingDoctor(doctor);

    setForm({
      name: doctor.name || "",
      email: doctor.email || "",
      phone: doctor.phone || "",
      specialty: doctor.specialty || "",
      department: doctor.department || "",
    });

    setShowEditModal(true);
  }

  // =========================
  // UPDATE DOCTOR
  // =========================

  async function handleUpdate(e) {
    e.preventDefault();

    if (!editingDoctor) return;

    try {
      setError("");

      const updatedDoctor = await updateDoctor(
        editingDoctor._id,
        {
          name: form.name,
          email: form.email,
          phone: form.phone,
          specialty: form.specialty,
          department: form.department,
          experience: editingDoctor.experience || 0,
          status: editingDoctor.status || "Active",
        },
      );

      setDoctors((prev) =>
        prev.map((doctor) =>
          doctor._id === editingDoctor._id
            ? updatedDoctor
            : doctor,
        ),
      );

      setShowEditModal(false);
      setEditingDoctor(null);

      setForm({
        name: "",
        email: "",
        phone: "",
        specialty: "",
        department: "",
      });
    } catch (err) {
      console.error(err);
      setError("Doctorni yangilashda xatolik");
    }
  }

  // =========================
  // DELETE DOCTOR
  // =========================

  async function handleDelete(id) {
    const confirmed = window.confirm(
      "Doctorni o'chirishni xohlaysizmi?",
    );

    if (!confirmed) return;

    try {
      setError("");

      await deleteDoctorApi(id);

      setDoctors((prev) =>
        prev.filter((doctor) => doctor._id !== id),
      );
    } catch (err) {
      console.error(err);
      setError("Doctorni o'chirishda xatolik");
    }
  }

  // =========================
  // ADD MODALNI YOPISH
  // =========================

  function closeAddModal() {
    setShowModal(false);

    setForm({
      name: "",
      email: "",
      phone: "",
      specialty: "",
      department: "",
    });
  }

  // =========================
  // EDIT MODALNI YOPISH
  // =========================

  function closeEditModal() {
    setShowEditModal(false);
    setEditingDoctor(null);

    setForm({
      name: "",
      email: "",
      phone: "",
      specialty: "",
      department: "",
    });
  }

  return (
    <div className="dashboard">
      {/* =========================
          SIDEBAR
      ========================= */}

      <aside className="sidebar">
        <div className="sidebar-brand">
          <div className="brand-icon">✚</div>
          <span>MedCare</span>
        </div>

        <p className="menu-title">MAIN MENU</p>

        <nav>
          <a href="/dashboard">
            <span>▦</span>
            Dashboard
          </a>

          <a href="/doctors" className="active">
            <span>⚕</span>
            Doctors
          </a>

          <a href="/patients">
            <span>♙</span>
            Patients
          </a>

          <a href="/appointments">
            <span>□</span>
            Appointments
          </a>

          <a href="/departments">
            <span>¤</span>
            Departments
          </a>
        </nav>

        <div className="sidebar-bottom">
          <a href="/settings">⚙ Settings</a>

          
        </div>
      </aside>

      {/* =========================
          MAIN
      ========================= */}

      <main className="dashboard-main">
        {/* TOPBAR */}

        <header className="topbar">
          <div>
            <h1>Doctors</h1>

            <p>Manage hospital doctors</p>
          </div>

          <div className="profile">
            <div className="avatar">A</div>

            <div>
              <strong>Admin</strong>

              <span>Administrator</span>
            </div>
          </div>
        </header>

        {/* TOOLBAR */}

        <div className="doctors-toolbar">
          <input
            type="text"
            placeholder="Search doctors..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />

          <button
            className="add-button"
            onClick={() => setShowModal(true)}
          >
            + Add Doctor
          </button>
        </div>

        {/* ERROR */}

        {error && <div className="empty">{error}</div>}

        {/* TABLE */}

        <div className="table-card">
          {loading ? (
            <div className="empty">
              Doctorlar yuklanmoqda...
            </div>
          ) : (
            <table>
              <thead>
                <tr>
                  <th>Doctor</th>
                  <th>Specialty</th>
                  <th>Department</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
              </thead>

              <tbody>
                {filteredDoctors.map((doctor) => (
                  <tr key={doctor._id}>
                    {/* DOCTOR */}

                    <td>
                      <div className="doctor-info">
                        <div className="doctor-avatar">
                          {doctor.name
                            ? doctor.name
                              .split(" ")
                              .map((word) => word[0])
                              .join("")
                            : "D"}
                        </div>

                        <div>
                          <strong>{doctor.name}</strong>

                          <span>{doctor.email}</span>
                        </div>
                      </div>
                    </td>

                    {/* SPECIALTY */}

                    <td>
                      {doctor.specialty}
                    </td>

                    {/* DEPARTMENT */}

                    <td>
                      {doctor.department ||
                        doctor.specialty}
                    </td>

                    {/* STATUS */}

                    <td>
                      <span
                        className={`doctor-status ${doctor.status === "Active"
                            ? "active-status"
                            : "inactive-status"
                          }`}
                      >
                        {doctor.status}
                      </span>
                    </td>

                    {/* ACTION */}

                    <td>
                      <div className="actions">
                        {/* EDIT */}

                        <button
                          title="Edit"
                          onClick={() =>
                            handleEdit(doctor)
                          }
                        >
                          ✏️
                        </button>

                        {/* DELETE */}

                        <button
                          title="Delete"
                          onClick={() =>
                            handleDelete(
                              doctor._id,
                            )
                          }
                        >
                          🗑️
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}

          {!loading &&
            filteredDoctors.length === 0 && (
              <div className="empty">
                Doctor topilmadi.
              </div>
            )}
        </div>
      </main>

      {/* =================================================
          ADD DOCTOR MODAL
      ================================================= */}

      {showModal && (
        <div
          className="modal-overlay"
          onClick={closeAddModal}
        >
          <div
            className="modal"
            onClick={(e) =>
              e.stopPropagation()
            }
          >
            <div className="modal-header">
              <div>
                <h2>Add Doctor</h2>

                <p>
                  Enter doctor information
                </p>
              </div>

              <button
                className="close-button"
                onClick={closeAddModal}
              >
                ×
              </button>
            </div>

            <form onSubmit={handleSubmit}>
              <label>Full name</label>

              <input
                name="name"
                placeholder="Dr. John Smith"
                value={form.name}
                onChange={handleChange}
                required
              />

              <label>Email</label>

              <input
                name="email"
                type="email"
                placeholder="doctor@medcare.com"
                value={form.email}
                onChange={handleChange}
                required
              />

              <label>Phone</label>

              <input
                name="phone"
                placeholder="+998901234567"
                value={form.phone}
                onChange={handleChange}
                required
              />

              <label>Specialty</label>

              <input
                name="specialty"
                placeholder="Cardiology"
                value={form.specialty}
                onChange={handleChange}
                required
              />

              <label>Department</label>

              <select
                name="department"
                value={form.department}
                onChange={handleChange}
                required
              >
                <option value="">
                  Select department
                </option>

                <option value="Cardiology">
                  Cardiology
                </option>

                <option value="Neurology">
                  Neurology
                </option>

                <option value="Pediatrics">
                  Pediatrics
                </option>

                <option value="Dentistry">
                  Dentistry
                </option>
              </select>

              <button
                className="save-button"
                type="submit"
              >
                Add Doctor
              </button>
            </form>
          </div>
        </div>
      )}

      {/* =================================================
          EDIT DOCTOR MODAL
      ================================================= */}

      {showEditModal && (
        <div
          className="modal-overlay"
          onClick={closeEditModal}
        >
          <div
            className="modal"
            onClick={(e) =>
              e.stopPropagation()
            }
          >
            <div className="modal-header">
              <div>
                <h2>Edit Doctor</h2>

                <p>
                  Update doctor information
                </p>
              </div>

              <button
                className="close-button"
                onClick={closeEditModal}
              >
                ×
              </button>
            </div>

            <form onSubmit={handleUpdate}>
              <label>Full name</label>

              <input
                name="name"
                placeholder="Dr. John Smith"
                value={form.name}
                onChange={handleChange}
                required
              />

              <label>Email</label>

              <input
                name="email"
                type="email"
                placeholder="doctor@medcare.com"
                value={form.email}
                onChange={handleChange}
                required
              />

              <label>Phone</label>

              <input
                name="phone"
                placeholder="+998901234567"
                value={form.phone}
                onChange={handleChange}
                required
              />

              <label>Specialty</label>

              <input
                name="specialty"
                placeholder="Cardiology"
                value={form.specialty}
                onChange={handleChange}
                required
              />

              <label>Department</label>

              <select
                name="department"
                value={form.department}
                onChange={handleChange}
                required
              >
                <option value="">
                  Select department
                </option>

                <option value="Cardiology">
                  Cardiology
                </option>

                <option value="Neurology">
                  Neurology
                </option>

                <option value="Pediatrics">
                  Pediatrics
                </option>

                <option value="Dentistry">
                  Dentistry
                </option>
              </select>

              <button
                className="save-button"
                type="submit"
              >
                Save Changes
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}