import { useEffect, useState } from "react";
import { Link } from "react-router-dom";

import {
  getDoctors,
  getPatients,
  getAppointments,
  getDepartments,
} from "../services/api";

export default function Dashboard() {
  const [doctors, setDoctors] = useState([]);
  const [patients, setPatients] = useState([]);
  const [appointments, setAppointments] = useState([]);
  const [departments, setDepartments] = useState([]);

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  // =========================
  // LOAD DATA
  // =========================

  useEffect(() => {
    loadDashboard();
  }, []);

  async function loadDashboard() {
    try {
      setLoading(true);
      setError("");

      const [
        doctorsData,
        patientsData,
        appointmentsData,
        departmentsData,
      ] = await Promise.all([
        getDoctors(),
        getPatients(),
        getAppointments(),
        getDepartments(),
      ]);

      setDoctors(doctorsData);
      setPatients(patientsData);
      setAppointments(appointmentsData);
      setDepartments(departmentsData);
    } catch (err) {
      console.error(err);

      setError(
        "Dashboard ma'lumotlarini yuklashda xatolik"
      );
    } finally {
      setLoading(false);
    }
  }

  // =========================
  // TODAY
  // =========================

  const today = new Date();

  const todayString =
    today.getFullYear() +
    "-" +
    String(today.getMonth() + 1).padStart(2, "0") +
    "-" +
    String(today.getDate()).padStart(2, "0");

  const todayAppointments = appointments.filter(
    (appointment) =>
      appointment.date === todayString
  );

  // =========================
  // COUNTS
  // =========================

  const totalDoctors = doctors.length;

  const totalPatients = patients.length;

  const totalAppointments =
    appointments.length;

  const totalDepartments =
    departments.length;

  const scheduledAppointments =
    appointments.filter(
      (appointment) =>
        appointment.status === "Scheduled"
    ).length;

  const completedAppointments =
    appointments.filter(
      (appointment) =>
        appointment.status === "Completed"
    ).length;

  const cancelledAppointments =
    appointments.filter(
      (appointment) =>
        appointment.status === "Cancelled"
    ).length;

  // =========================
  // STATS
  // =========================

  const stats = [
    {
      title: "Total Doctors",
      value: totalDoctors,
      icon: "👨‍⚕️",
    },
    {
      title: "Total Patients",
      value: totalPatients,
      icon: "🧑‍🤝‍🧑",
    },
    {
      title: "Appointments",
      value: totalAppointments,
      icon: "📅",
    },
    {
      title: "Departments",
      value: totalDepartments,
      icon: "🏥",
    },
  ];

  // =========================
  // TIME FORMAT
  // =========================

  function formatTime(time) {
    if (!time) {
      return "-";
    }

    const [hours, minutes] = time.split(":");

    const hourNumber = Number(hours);

    const period =
      hourNumber >= 12 ? "PM" : "AM";

    const displayHour =
      hourNumber % 12 || 12;

    return `${displayHour}:${minutes} ${period}`;
  }

  // =========================
  // STATUS
  // =========================

  function getStatusClass(status) {
    if (status === "Completed") {
      return "confirmed";
    }

    if (status === "Cancelled") {
      return "pending";
    }

    return "confirmed";
  }

  // =========================
  // DOCTOR SPECIALTY
  // =========================

  function getDoctorSpecialty(doctor) {
    return (
      doctor?.specialty ||
      doctor?.department ||
      "General"
    );
  }

  // =========================
  // PATIENT INITIALS
  // =========================

  function getPatientInitials(name) {
    if (!name) {
      return "P";
    }

    return name
      .split(" ")
      .filter(Boolean)
      .map((word) => word[0])
      .join("")
      .slice(0, 2)
      .toUpperCase();
  }

  return (
    <div className="dashboard">

      {/* =========================
          SIDEBAR
      ========================= */}

      <aside className="sidebar">

        <div className="sidebar-brand">
          <div className="brand-icon">
            ✚
          </div>

          <span>MedCare</span>
        </div>

        <p className="menu-title">
          MAIN MENU
        </p>

        <nav>

          <Link
            className="active"
            to="/dashboard"
          >
            <span>▦</span>
            Dashboard
          </span>

          <Link to="/doctors">
            <span>⚕</span>
            Doctors
          </span>

          <Link to="/patients">
            <span>♙</span>
            Patients
          </span>

          <Link to="/appointments">
            <span>□</span>
            Appointments
          </span>

          <Link to="/departments">
            <span>▤</span>
            Departments
          </span>

        </nav>

        <div className="sidebar-bottom">

          <Link to="/settings">
            ⚙ Settings
          </span>

          <span>
            ↪ Logout
          </span>

        </div>

      </aside>

      {/* =========================
          MAIN
      ========================= */}

      <main className="dashboard-main">

        {/* =========================
            TOPBAR
        ========================= */}

        <header className="topbar">

          <div>

            <h1>Dashboard</h1>

            <p>
              Good morning, Admin 👋
            </p>

          </div>

          <div className="profile">

            <div className="avatar">
              A
            </div>

            <div>
              <strong>Admin</strong>

              <span>
                Administrator
              </span>
            </div>

          </div>

        </header>

        {/* =========================
            ERROR
        ========================= */}

        {error && (
          <div className="dashboard-error">
            {error}
          </div>
        )}

        {/* =========================
            STATS
        ========================= */}

        <section className="stats-grid">

          {stats.map((stat) => (

            <div
              className="stat-card"
              key={stat.title}
            >

              <div className="stat-icon">
                {stat.icon}
              </div>

              <div>

                <p>
                  {stat.title}
                </p>

                <h2>
                  {loading
                    ? "..."
                    : stat.value}
                </h2>

              </div>

            </div>

          ))}

        </section>

        {/* =========================
            TODAY + OVERVIEW
        ========================= */}

        <section className="content-grid">

          {/* =========================
              TODAY APPOINTMENTS
          ========================= */}

          <div className="panel">

            <div className="panel-header">

              <div>

                <h3>
                  Today's Appointments
                </h3>

                <p>
                  Recent appointments for today
                </p>

              </div>

              <Link to="/appointments">
                View all
              </span>

            </div>

            {loading ? (

              <div className="dashboard-empty">
                Appointments yuklanmoqda...
              </div>

            ) : todayAppointments.length ===
              0 ? (

              <div className="dashboard-empty">
                Bugun appointment yo'q
              </div>

            ) : (

              todayAppointments
                .slice(0, 5)
                .map((appointment) => (

                  <div
                    className="appointment"
                    key={appointment._id}
                  >

                    {/* PATIENT AVATAR */}

                    <div className="appointment-avatar">

                      {getPatientInitials(
                        appointment.patient?.name
                      )}

                    </div>

                    {/* PATIENT + DOCTOR */}

                    <div className="appointment-info">

                      <strong>
                        {appointment.patient
                          ?.name ||
                          "Unknown Patient"}
                      </strong>

                      <span>

                        {appointment.doctor
                          ?.name ||
                          "Unknown Doctor"}

                        {" · "}

                        {getDoctorSpecialty(
                          appointment.doctor
                        )}

                      </span>

                    </div>

                    {/* TIME + STATUS */}

                    <div className="appointment-time">

                      <strong>
                        {formatTime(
                          appointment.time
                        )}
                      </strong>

                      <span
                        className={`status ${getStatusClass(
                          appointment.status
                        )}`}
                      >
                        {appointment.status}
                      </span>

                    </div>

                  </div>

                ))

            )}

          </div>

          {/* =========================
              HOSPITAL OVERVIEW
          ========================= */}

          <div className="panel">

            <div className="panel-header">

              <div>

                <h3>
                  Hospital Overview
                </h3>

                <p>
                  Current system data
                </p>

              </div>

            </div>

            {/* DOCTORS */}

            <div className="department">

              <span>
                👨‍⚕️
              </span>

              <div>

                <strong>
                  Doctors
                </strong>

                <small>
                  {loading
                    ? "Loading..."
                    : `${totalDoctors} Doctors`}
                </small>

              </div>

            </div>

            {/* PATIENTS */}

            <div className="department">

              <span>
                🧑‍🤝‍🧑
              </span>

              <div>

                <strong>
                  Patients
                </strong>

                <small>
                  {loading
                    ? "Loading..."
                    : `${totalPatients} Patients`}
                </small>

              </div>

            </div>

            {/* APPOINTMENTS */}

            <div className="department">

              <span>
                📅
              </span>

              <div>

                <strong>
                  Appointments
                </strong>

                <small>
                  {loading
                    ? "Loading..."
                    : `${totalAppointments} Appointments`}
                </small>

              </div>

            </div>

            {/* DEPARTMENTS */}

            <div className="department">

              <span>
                🏥
              </span>

              <div>

                <strong>
                  Departments
                </strong>

                <small>
                  {loading
                    ? "Loading..."
                    : `${totalDepartments} Departments`}
                </small>

              </div>

            </div>

            {/* SCHEDULED */}

            <div className="department">

              <span>
                🕐
              </span>

              <div>

                <strong>
                  Scheduled
                </strong>

                <small>
                  {loading
                    ? "Loading..."
                    : `${scheduledAppointments} Scheduled`}
                </small>

              </div>

            </div>

          </div>

        </section>

        {/* =========================
            APPOINTMENT SUMMARY
        ========================= */}

        <section
          className="content-grid"
          style={{
            marginTop: "20px",
          }}
        >

          {/* =========================
              SUMMARY
          ========================= */}

          <div className="panel">

            <div className="panel-header">

              <div>

                <h3>
                  Appointment Summary
                </h3>

                <p>
                  Current appointment status
                </p>

              </div>

              <Link to="/appointments">
                Manage
              </span>

            </div>

            {/* SCHEDULED */}

            <div className="department">

              <span>
                🕐
              </span>

              <div>

                <strong>
                  Scheduled
                </strong>

                <small>
                  {loading
                    ? "Loading..."
                    : `${scheduledAppointments} appointments`}
                </small>

              </div>

            </div>

            {/* COMPLETED */}

            <div className="department">

              <span>
                ✅
              </span>

              <div>

                <strong>
                  Completed
                </strong>

                <small>
                  {loading
                    ? "Loading..."
                    : `${completedAppointments} appointments`}
                </small>

              </div>

            </div>

            {/* CANCELLED */}

            <div className="department">

              <span>
                ❌
              </span>

              <div>

                <strong>
                  Cancelled
                </strong>

                <small>
                  {loading
                    ? "Loading..."
                    : `${cancelledAppointments} appointments`}
                </small>

              </div>

            </div>

          </div>

          {/* =========================
              DEPARTMENTS
          ========================= */}

          <div className="panel">

            <div className="panel-header">

              <div>

                <h3>
                  Departments
                </h3>

                <p>
                  Hospital departments
                </p>

              </div>

              <Link to="/departments">
                View all
              </span>

            </div>

            {loading ? (

              <div className="dashboard-empty">
                Departments yuklanmoqda...
              </div>

            ) : departments.length === 0 ? (

              <div className="dashboard-empty">
                Department mavjud emas
              </div>

            ) : (

              departments
                .slice(0, 5)
                .map((department) => (

                  <div
                    className="department department-no-icon"
                    key={department._id}
                  >

                    <div>

                      <strong>
                        {department.name}
                      </strong>

                      <small>
                        {department.description ||
                          "Hospital department"}
                      </small>

                    </div>

                  </div>

                ))

            )}

          </div>

        </section>

      </main>

    </div>
  );
}