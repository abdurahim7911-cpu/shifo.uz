import { askConfirm } from "./confirm";
import { useEffect, useMemo, useState } from "react";
import Login from "./Login";
import Patient from "./Patient";
import Appointment from "./Appointment";
import Department from "./Department";
import {
  getDoctors,
  createDoctor,
  updateDoctor,
  deleteDoctor,
  getPatients,
  getAppointments,
  getDepartments,
  getDashboardStats,
  getProfile,
  updateProfile,
  createSupportTicket,
} from "./services/api";
import "./App.css";

const navItems = [
  { id: "dashboard", label: "Dashboard", icon: "grid" },
  { id: "doctors", label: "Doctors", icon: "doctor" },
  { id: "patients", label: "Patients", icon: "users" },
  { id: "appointments", label: "Appointments", icon: "calendar" },
  { id: "departments", label: "Departments", icon: "hospital" },
];

function Icon({ name, size = 18, stroke = 1.8 }) {
  const paths = {
    grid: <><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></>,
    doctor: <><circle cx="12" cy="7" r="3.2"/><path d="M5 21c.6-4 3-6 7-6s6.4 2 7 6"/><path d="M17.5 11.5v3M16 13h3"/></>,
    users: <><circle cx="9" cy="8" r="3"/><path d="M3.5 20c.5-3.7 2.4-5.5 5.5-5.5s5 1.8 5.5 5.5"/><path d="M16 5.5a3 3 0 0 1 0 5.7M17 14.7c2.2.4 3.5 2 4 4.3"/></>,
    calendar: <><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 10h18"/><path d="M8 14h.01M12 14h.01M16 14h.01M8 18h.01M12 18h.01"/></>,
    hospital: <><path d="M4 21V5a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v16"/><path d="M2 21h20M8 7h4M10 5v4M10 16v5M7 12h2M12 12h2M7 16h2M12 16h2"/><path d="M16 9h2a2 2 0 0 1 2 2v10"/></>,
    search: <><circle cx="10.8" cy="10.8" r="6.7"/><path d="m16 16 5 5"/></>,
    bell: <><path d="M18 9a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4"/></>,
    sun: <><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.42 1.42M17.65 17.65l1.42 1.42M2 12h2M20 12h2M4.93 19.07l1.42-1.42M17.65 6.35l1.42-1.42"/></>,
    menu: <><path d="M4 7h16M4 12h16M4 17h16"/></>,
    plus: <><path d="M12 5v14M5 12h14"/></>,
    arrow: <><path d="M5 12h14M13 6l6 6-6 6"/></>,
    more: <><circle cx="5" cy="12" r="1" fill="currentColor" stroke="none"/><circle cx="12" cy="12" r="1" fill="currentColor" stroke="none"/><circle cx="19" cy="12" r="1" fill="currentColor" stroke="none"/></>,
    activity: <><path d="M3 12h4l2.5-6 5 12 2.5-6H21"/></>,
    check: <><path d="m5 12 4 4L19 6"/></>,
    logout: <><path d="M10 17l5-5-5-5M15 12H3M21 19V5a2 2 0 0 0-2-2h-5"/></>,
    close: <><path d="m6 6 12 12M18 6 6 18"/></>,
    settings: <><path d="M12 3v2M12 19v2M3 12h2M19 12h2M5.6 5.6l1.4 1.4M17 17l1.4 1.4M18.4 5.6 17 7M7 17l-1.4 1.4"/><circle cx="12" cy="12" r="3.2"/></>,
    help: <><circle cx="12" cy="12" r="9"/><path d="M9.6 9a2.5 2.5 0 1 1 4.3 1.8c-.9.8-1.9 1.2-1.9 2.5M12 17h.01"/></>,
    mail: <><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m4 7 8 6 8-6"/></>,
    lock: <><rect x="5" y="10" width="14" height="10" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></>,
    save: <><path d="M5 3h12l2 2v16H5z"/><path d="M8 3v6h8V3M8 21v-6h8v6"/></>,
    edit: <><path d="m4 20 4.5-1 9.8-9.8a2.1 2.1 0 0 0-3-3L5.5 16zM13.5 7.5l3 3"/></>,
    clock: <><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></>,
    hourglass: <><path d="M6 3h12M6 21h12M7 3c0 5 5 5 5 9s-5 4-5 9M17 3c0 5-5 5-5 9s5 4 5 9"/></>,
    moon: <><path d="M20 14.5A8 8 0 0 1 9.5 4a8 8 0 1 0 10.5 10.5z"/></>,
    wifi: <><path d="M2 9a15 15 0 0 1 20 0M5.5 12.5a10 10 0 0 1 13 0M9 16a5 5 0 0 1 6 0"/><circle cx="12" cy="19.5" r=".9" fill="currentColor" stroke="none"/></>,
    wifioff: <><path d="M3 3l18 18M2 9a15 15 0 0 1 5-3.2M10 4.1A15 15 0 0 1 22 9M5.5 12.5a10 10 0 0 1 3.2-2M14 10.3a10 10 0 0 1 4.5 2.2M9 16a5 5 0 0 1 6 0"/><circle cx="12" cy="19.5" r=".9" fill="currentColor" stroke="none"/></>,
    trash: <><path d="M4 7h16M10 11v6M14 11v6M6 7l1 14h10l1-14M9 7V4h6v3"/></>,
  };
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{paths[name]}</svg>;
}

function apptStatus(v) {
  const t = String(v || "").toLowerCase();
  if (t.includes("complet")) return { cls: "done", icon: "check", label: "Completed" };
  if (t.includes("cancel")) return { cls: "cancel", icon: "close", label: "Cancelled" };
  if (t.includes("pend") || t.includes("wait")) return { cls: "wait", icon: "hourglass", label: "Pending" };
  return { cls: "sched", icon: "calendar", label: "Scheduled" };
}
function dayParts(date) {
  const x = new Date(String(date || "") + "T00:00:00");
  if (isNaN(x)) return { d: "—", m: "" };
  return { d: String(x.getDate()).padStart(2, "0"), m: x.toLocaleString("en", { month: "short" }) };
}

function initials(value, fallback = "M") {
  const text = String(value || fallback).trim();
  return text.split(/\s+/).slice(0, 2).map((part) => part[0]).join("").toUpperCase();
}

function unwrapArray(value, key) {
  if (Array.isArray(value)) return value;
  if (Array.isArray(value?.[key])) return value[key];
  return [];
}

export default function App() {
  const [user, setUser] = useState(() => {
    try { return JSON.parse(localStorage.getItem("medcare_user") || sessionStorage.getItem("medcare_user") || "null"); } catch { return null; }
  });
  const [page, setPage] = useState(() => {
    const route = window.location.hash.replace(/^#\/?/, "").split("/")[0];
    return navItems.some((item) => item.id === route) ? route : "dashboard";
  });
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [doctors, setDoctors] = useState([]);
  const [patients, setPatients] = useState([]);
  const [appointments, setAppointments] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [dashboardStats, setDashboardStats] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [search, setSearch] = useState("");
  const [online, setOnline] = useState(typeof navigator === "undefined" ? true : navigator.onLine);
  const [searchFocus, setSearchFocus] = useState(false);
  const [theme, setTheme] = useState(() => localStorage.getItem("medcare_theme") || "light");
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [helpOpen, setHelpOpen] = useState(false);
  const [settingsTab, setSettingsTab] = useState("profile");
  const [settingsForm, setSettingsForm] = useState({ name: "", email: "", currentPassword: "", newPassword: "" });
  const [preferences, setPreferences] = useState(() => {
    try { return JSON.parse(localStorage.getItem("medcare_preferences") || "null") || { notifications: true, compact: false }; } catch { return { notifications: true, compact: false }; }
  });
  const [supportForm, setSupportForm] = useState({ subject: "", message: "" });
  const [supportSending, setSupportSending] = useState(false);
  const [supportSent, setSupportSent] = useState(false);
  const [showDoctorModal, setShowDoctorModal] = useState(false);
  const [editingDoctor, setEditingDoctor] = useState(null);
  const [doctorForm, setDoctorForm] = useState({ name: "", email: "", phone: "", specialty: "", department: "" });

  const displayName = user?.name || "Administrator";
  const firstName = displayName.split(" ")[0] || "Admin";

  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    localStorage.setItem("medcare_theme", theme);
  }, [theme]);

  useEffect(() => {
    const up = () => { setOnline(true); if (user && page === "dashboard") { loadDoctors(); loadDashboardData(); } };
    const down = () => setOnline(false);
    window.addEventListener("online", up);
    window.addEventListener("offline", down);
    return () => { window.removeEventListener("online", up); window.removeEventListener("offline", down); };
  }, [user, page]);

  useEffect(() => {
    if (!user || page !== "dashboard" || !online) return;
    const t = setInterval(() => { loadDashboardData(); }, 30000);
    return () => clearInterval(t);
  }, [user, page, online]);

  // Hash-based navigation preserves the active section on Ctrl+R / browser refresh.
  useEffect(() => {
    if (!window.location.hash) window.history.replaceState(null, "", `${window.location.pathname}${window.location.search}#/dashboard`);
    const syncPageFromHash = () => {
      const route = window.location.hash.replace(/^#\/?/, "").split("/")[0];
      if (navItems.some((item) => item.id === route)) setPage(route);
    };
    window.addEventListener("hashchange", syncPageFromHash);
    return () => window.removeEventListener("hashchange", syncPageFromHash);
  }, []);

  useEffect(() => {
    localStorage.setItem("medcare_preferences", JSON.stringify(preferences));
    document.documentElement.classList.toggle("compact-mode", !!preferences.compact);
  }, [preferences]);

  useEffect(() => {
    const onKeyDown = (event) => {
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "k") {
        event.preventDefault();
        document.querySelector(".global-search input")?.focus();
      }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, []);

  async function openSettings(tab = "profile") {
    setSettingsTab(tab);
    setProfileOpen(false);
    setNotificationsOpen(false);
    setSettingsOpen(true);
    setSettingsForm({ name: user?.name || "", email: user?.email || "", currentPassword: "", newPassword: "" });
    if (user?.id) {
      try {
        const result = await getProfile(user.id);
        const freshUser = result.user || result;
        setSettingsForm((prev) => ({ ...prev, name: freshUser.name || prev.name, email: freshUser.email || prev.email }));
      } catch { /* local user data is enough to open settings */ }
    }
  }

  function openHelp() {
    setHelpOpen(true);
    setProfileOpen(false);
    setNotificationsOpen(false);
    setSupportSent(false);
  }

  async function saveSettings(event) {
    event.preventDefault();
    if (!user?.id) return;
    try {
      setLoading(true);
      const result = await updateProfile(user.id, settingsForm);
      const updatedUser = result.user || result;
      localStorage.setItem("medcare_user", JSON.stringify(updatedUser));
      sessionStorage.setItem("medcare_user", JSON.stringify(updatedUser));
      setUser(updatedUser);
      setSettingsForm((prev) => ({ ...prev, currentPassword: "", newPassword: "" }));
      setError("");
      setSettingsTab("saved");
    } catch (err) {
      setError(err.message || "Settingsni saqlashda xatolik");
    } finally {
      setLoading(false);
    }
  }

  async function submitSupport(event) {
    event.preventDefault();
    if (!supportForm.subject.trim() || !supportForm.message.trim()) return;
    try {
      setSupportSending(true);
      await createSupportTicket({ userId: user?.id, name: displayName, email: user?.email, ...supportForm });
      setSupportSent(true);
      setSupportForm({ subject: "", message: "" });
    } catch (err) {
      setError(err.message || "Support so'rovini yuborishda xatolik");
    } finally {
      setSupportSending(false);
    }
  }

  function handleLogin(loggedUser) {
    localStorage.setItem("medcare_user", JSON.stringify(loggedUser));
    sessionStorage.setItem("medcare_user", JSON.stringify(loggedUser));
    window.location.hash = "#/dashboard";
    setUser(loggedUser);
    setPage("dashboard");
  }

  function handleLogout() {
    sessionStorage.removeItem("medcare_user");
    localStorage.removeItem("medcare_user");
    setUser(null);
    setSidebarOpen(false);
  }

  async function loadDoctors() {
    try {
      setLoading(true);
      setError("");
      setDoctors(unwrapArray(await getDoctors(), "doctors"));
    } catch (err) {
      setError(err.message || "Doctorlarni olishda xatolik");
    } finally {
      setLoading(false);
    }
  }

  async function loadDashboardData() {
    try {
      setError("");
      const [patientsData, appointmentsData, departmentsData, statsData] = await Promise.all([getPatients(), getAppointments(), getDepartments(), getDashboardStats()]);
      setPatients(unwrapArray(patientsData, "patients"));
      setAppointments(unwrapArray(appointmentsData, "appointments"));
      setDepartments(unwrapArray(departmentsData, "departments"));
      setDashboardStats(statsData);
    } catch (err) {
      setError(err.message || "Dashboard ma'lumotlarini olishda xatolik");
    }
  }

  useEffect(() => {
    if (!user) return;
    if (page === "doctors") loadDoctors();
    if (page === "dashboard") {
      loadDoctors();
      loadDashboardData();
    }
  }, [page, user]);

  function openCreateDoctor() {
    setEditingDoctor(null);
    setDoctorForm({ name: "", email: "", phone: "", specialty: "", department: "" });
    setShowDoctorModal(true);
  }

  function openEditDoctor(doctor) {
    setEditingDoctor(doctor);
    setDoctorForm({
      name: doctor.name || "",
      email: doctor.email || "",
      phone: doctor.phone || "",
      specialty: doctor.specialty || doctor.specialization || "",
      department: doctor.department || "",
    });
    setShowDoctorModal(true);
  }

  async function handleDoctorSubmit(e) {
    e.preventDefault();
    try {
      setLoading(true);
      setError("");
      if (editingDoctor) await updateDoctor(editingDoctor._id || editingDoctor.id, doctorForm);
      else await createDoctor(doctorForm);
      setShowDoctorModal(false);
      setEditingDoctor(null);
      await loadDoctors();
    } catch (err) {
      setError(err.message || "Doctorni saqlashda xatolik");
    } finally {
      setLoading(false);
    }
  }

  async function handleDeleteDoctor(id) {
    if (!(await askConfirm({ title: "Shifokorni o'chirish", message: "Bu shifokor va uning barcha uchrashuvlari o'chiriladi. Davom etasizmi?" }))) return;
    try {
      setLoading(true);
      setError("");
      await deleteDoctor(id);
      await loadDoctors();
    } catch (err) {
      setError(err.message || "Doctorni o'chirishda xatolik");
    } finally {
      setLoading(false);
    }
  }

  const filteredDoctors = useMemo(() => doctors.filter((doctor) => `${doctor.name || ""} ${doctor.email || ""} ${doctor.phone || ""} ${doctor.specialty || doctor.specialization || ""} ${doctor.department || ""}`.toLowerCase().includes(search.toLowerCase())), [doctors, search]);

  const todayString = new Date().toISOString().split("T")[0];
  const todayAppointments = appointments.filter((appointment) => {
    const date = appointment.date || appointment.appointmentDate;
    if (!date) return false;
    try { return new Date(date).toISOString().split("T")[0] === todayString; } catch { return false; }
  });

  const searchText = search.trim().toLowerCase();
  const dashboardDoctors = doctors.filter((doctor) => {
    if (!searchText) return true;
    return `${doctor.name || ""} ${doctor.email || ""} ${doctor.specialty || doctor.specialization || ""} ${doctor.department || ""}`.toLowerCase().includes(searchText);
  });
  const dashboardDepartments = departments.filter((department) => {
    if (!searchText) return true;
    return `${department.name || ""} ${department.description || ""}`.toLowerCase().includes(searchText);
  });
  const dashboardAppointments = appointments.filter((appointment) => {
    if (!searchText) return true;
    const patient = appointment.patientName || appointment.patient?.name || appointment.patient || "";
    const doctor = appointment.doctorName || appointment.doctor?.name || appointment.doctor || "";
    return `${patient} ${doctor} ${appointment.reason || ""} ${appointment.status || ""}`.toLowerCase().includes(searchText);
  });

  const statCards = [
    { label: "Total Doctors", value: dashboardStats?.doctors ?? doctors.length, tone: "blue", icon: "doctor", note: "Medical specialists" },
    { label: "Total Patients", value: dashboardStats?.patients ?? patients.length, tone: "green", icon: "users", note: "Registered patients" },
    { label: "Appointments", value: dashboardStats?.appointments ?? appointments.length, tone: "purple", icon: "calendar", note: "All appointments" },
    { label: "Departments", value: dashboardStats?.departments ?? departments.length, tone: "orange", icon: "hospital", note: "Hospital units" },
  ];

  const weeklyAppointmentCounts = useMemo(() => {
    const today = new Date();
    const monday = new Date(today);
    monday.setHours(0, 0, 0, 0);
    monday.setDate(today.getDate() - ((today.getDay() + 6) % 7));
    const labels = ["Dush", "Sesh", "Chor", "Pay", "Jum", "Shan", "Yak"];
    return labels.map((label, index) => {
      const day = new Date(monday);
      day.setDate(monday.getDate() + index);
      const key = day.getFullYear() + "-" + String(day.getMonth() + 1).padStart(2, "0") + "-" + String(day.getDate()).padStart(2, "0");
      const count = appointments.filter((appointment) => String(appointment.date || appointment.appointmentDate || "").slice(0, 10) === key).length;
      return { label, count, key };
    });
  }, [appointments]);

  const searchResults = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (page !== "dashboard" || q.length < 2) return [];
    const nm = (v) => (typeof v === "string" ? v : v?.name || "");
    const hit = (...a) => a.join(" ").toLowerCase().includes(q);
    const out = [];
    doctors.forEach((d) => hit(d.name, d.specialty, d.department, d.email) && out.push({ type: "Doctor", icon: "doctor", label: d.name, sub: d.specialty || d.department || "", to: "doctors" }));
    patients.forEach((p) => hit(p.name, p.email, p.phone) && out.push({ type: "Patient", icon: "users", label: p.name, sub: p.phone || p.email || "", to: "patients" }));
    appointments.forEach((a) => hit(nm(a.patient), nm(a.doctor), a.reason, a.date) && out.push({ type: "Appointment", icon: "calendar", label: nm(a.patient) + " · " + nm(a.doctor), sub: (a.date || "") + " " + (a.time || ""), to: "appointments" }));
    departments.forEach((d) => hit(d.name, d.description) && out.push({ type: "Department", icon: "hospital", label: d.name, sub: d.description || "", to: "departments" }));
    return out.slice(0, 8);
  }, [search, page, doctors, patients, appointments, departments]);

  const deptStats = useMemo(() => {
    const palette = ["#14b8a6", "#6366f1", "#f59e0b", "#ef4444", "#0ea5e9", "#a855f7"];
    const byId = new Map(doctors.map((d) => [String(d._id || d.id), d.department || d.specialty || "Boshqa"]));
    const counts = {};
    appointments.forEach((a) => {
      const did = String(a.doctor?._id || a.doctor?.id || a.doctor || "");
      const name = byId.get(did) || a.doctor?.specialty || "Boshqa";
      counts[name] = (counts[name] || 0) + 1;
    });
    const total = appointments.length;
    let acc = 0;
    const rows = Object.entries(counts).sort((x, y) => y[1] - x[1]).map(([name, count], i) => {
      const from = total ? (acc / total) * 360 : 0; acc += count; const to = total ? (acc / total) * 360 : 0;
      return { name, count, pct: total ? Math.round((count / total) * 100) : 0, color: palette[i % palette.length], from, to };
    });
    const bg = rows.length ? "conic-gradient(" + rows.map((r) => r.color + " " + r.from + "deg " + r.to + "deg").join(",") + ")" : "";
    const status = { Scheduled: 0, Pending: 0, Completed: 0, Cancelled: 0 };
    appointments.forEach((a) => { const t = String(a.status || "").toLowerCase(); if (t.includes("complet")) status.Completed++; else if (t.includes("cancel")) status.Cancelled++; else if (t.includes("pend") || t.includes("wait")) status.Pending++; else status.Scheduled++; });
    return { rows, total, bg, status };
  }, [appointments, doctors]);

  const goTo = (nextPage) => {
    if (window.location.hash !== `#/${nextPage}`) window.location.hash = `#/${nextPage}`;
    setPage(nextPage);
    setSidebarOpen(false);
    setSearch("");
    setNotificationsOpen(false);
    setProfileOpen(false);
  };

  if (!user) return <Login onLogin={handleLogin} />;

  const pageTitle = navItems.find((item) => item.id === page)?.label || "Dashboard";

  return (
    <div className="app-shell">
      {sidebarOpen && <button className="mobile-backdrop" aria-label="Close menu" onClick={() => setSidebarOpen(false)} />}

      <aside className={`sidebar ${sidebarOpen ? "sidebar-open" : ""}`}>
        <div className="brand-row brand-link" role="button" tabIndex={0} title="Dashboardga o'tish" onClick={() => goTo("dashboard")} onKeyDown={(e) => { if (e.key === "Enter") goTo("dashboard"); }}>
          <div className="brand-mark"><Icon name="activity" size={20} /></div>
          <div className="brand-text"><strong>Med<span>Care</span></strong><small>Hospital Admin</small></div>
          <button className="mobile-close" onClick={(e) => { e.stopPropagation(); setSidebarOpen(false); }}><Icon name="close" /></button>
        </div>

        <div className="sidebar-label">MAIN MENU</div>
        <nav className="sidebar-nav">
          {navItems.map((item) => (
            <button key={item.id} className={`nav-item ${page === item.id ? "active" : ""}`} onClick={() => goTo(item.id)}>
              <span className="nav-icon"><Icon name={item.icon} size={18} /></span>
              <span>{item.label}</span>
              {item.id === "appointments" && todayAppointments.length > 0 && <em>{todayAppointments.length}</em>}
            </button>
          ))}
        </nav>

        <div className="sidebar-spacer" />
        <div className="sidebar-label">ACCOUNT</div>
        <button className="nav-item" onClick={() => openSettings()}><span className="nav-icon"><Icon name="settings" size={18} /></span><span>Settings</span></button>
        <button className="nav-item" onClick={openHelp}><span className="nav-icon"><Icon name="help" size={18} /></span><span>Help & Support</span></button>
        <button className="nav-item" onClick={handleLogout}><span className="nav-icon"><Icon name="logout" size={18} /></span><span>Logout</span></button>
        <div className="sidebar-theme-row">
          <span><Icon name={theme === "light" ? "sun" : "moon"} size={15} /> {theme === "light" ? "Light mode" : "Dark mode"}</span>
          <button type="button" className={`theme-switch ${theme === "dark" ? "on" : ""}`} aria-label="Toggle theme" onClick={() => setTheme((value) => value === "light" ? "dark" : "light")}><i /></button>
        </div>
        <div className="sidebar-footer">MedCare Management<br /><span>v1.0 • Secure workspace</span></div>
      </aside>

      <main className="main-content">
        <header className="topbar">
          <div className="topbar-left">
            <button className="mobile-menu" onClick={() => setSidebarOpen(true)}><Icon name="menu" /></button>
            <div className="breadcrumb"><span>MedCare</span><b>/</b><strong>{pageTitle}</strong></div>
          </div>
          <div className="topbar-actions">
            <div className="global-search-wrap"><label className="global-search">
              <Icon name="search" size={17} />
              <input value={search} onChange={(e) => setSearch(e.target.value)} onFocus={() => setSearchFocus(true)} onBlur={() => setTimeout(() => setSearchFocus(false), 150)} onKeyDown={(e) => { if (e.key === "Escape") { setSearch(""); e.target.blur(); } }} placeholder={page === "dashboard" ? "Shifokor, bemor, uchrashuv..." : `Search ${page}...`} />
              {search ? <button type="button" className="search-clear" aria-label="Tozalash" onMouseDown={(e) => e.preventDefault()} onClick={() => setSearch("")}><Icon name="close" size={14} /></button> : <kbd>Ctrl K</kbd>}
            </label>
            {searchFocus && page === "dashboard" && search.trim().length >= 2 && <div className="search-results">{searchResults.length ? searchResults.map((r, i) => <button type="button" key={i} onMouseDown={(e) => e.preventDefault()} onClick={() => { const q = r.label.split(" · ")[0]; goTo(r.to); setTimeout(() => setSearch(q), 0); }}><span className="sr-ico"><Icon name={r.icon} size={16} /></span><span className="sr-txt"><b>{r.label}</b><small>{r.sub}</small></span><em>{r.type}</em></button>) : <div className="sr-empty">"{search}" bo'yicha hech narsa topilmadi.</div>}</div>}</div>
            <button className="icon-button" aria-label="Toggle light mode" title={theme === "light" ? "Qorong'u rejimga o'tish" : "Yorug' rejimga o'tish"} onClick={() => setTheme((value) => value === "light" ? "dark" : "light")}><span className="theme-ico" key={theme}><Icon name={theme === "light" ? "sun" : "moon"} size={18} /></span></button>
            <span className={`net-pill ${online ? "on" : "off"}`} title={online ? "Internetga ulangan" : "Internet yo'q"}><Icon name={online ? "wifi" : "wifioff"} size={14} /><span>{online ? "Online" : "Offline"}</span></span>
            <div className="topbar-popover-wrap">
              <button className="icon-button notification" aria-label="Notifications" onClick={() => { setNotificationsOpen((value) => !value); setProfileOpen(false); }}><Icon name="bell" size={18} /><i /></button>
              {notificationsOpen && <div className="topbar-popover notification-popover"><strong>Notifications</strong><p>{todayAppointments.length ? `${todayAppointments.length} appointment(s) today.` : "No new appointments today."}</p><button onClick={() => { goTo("appointments"); setNotificationsOpen(false); }}>Open appointments</button></div>}
            </div>
            <div className="topbar-popover-wrap">
              <button className="profile-chip" onClick={() => { setProfileOpen((value) => !value); setNotificationsOpen(false); }} title="Account menu">
                <span className="avatar">{initials(displayName)}</span>
                <span className="profile-copy"><strong>{firstName}</strong><small>Administrator</small></span>
                <span className="profile-chevron">⌄</span>
              </button>
              {profileOpen && <div className="topbar-popover profile-popover"><div className="profile-popover-head"><span className="avatar">{initials(displayName)}</span><div><strong>{displayName}</strong><small>{user?.email || "Administrator"}</small></div></div><button onClick={() => openSettings("profile")}><Icon name="settings" size={13} /> Account settings</button><button onClick={() => openHelp()}><Icon name="help" size={13} /> Help & Support</button><button onClick={() => setTheme((value) => value === "light" ? "dark" : "light")}>{theme === "light" ? "Dark mode" : "Light mode"}</button><button className="danger-popover" onClick={handleLogout}>Logout</button></div>}
            </div>
          </div>
        </header>

        <div className="page-content">
          {!online && <div className="offline-banner"><Icon name="wifioff" size={18} /><div><strong>Internet aloqasi uzildi</strong><span>Ma'lumotlar yangilanmaydi. Aloqa tiklanganda avtomatik yangilanadi.</span></div></div>}
          {error && <div className="app-error"><span>!</span>{error}<button onClick={() => setError("")}><Icon name="close" size={15} /></button></div>}

          {page === "dashboard" && (
            <section className="reference-dashboard">
              <div className="dash-welcome">
                <div><h1>Assalomu alaykum, {firstName}!</h1><p>Bugun klinikangiz uchun muhim ma'lumotlar.</p></div>
                <div className="dash-date"><div><Icon name="calendar" size={21}/><span>Bugun</span><b>{new Date().toLocaleDateString('uz-UZ',{day:'2-digit',month:'long',year:'numeric'})}</b></div><div><Icon name="activity" size={21}/><span>Toshkent vaqti</span><b>{new Date().toLocaleTimeString('uz-UZ',{hour:'2-digit',minute:'2-digit'})}</b></div></div>
              </div>

              <div className="ref-stat-grid">
                {[{label:'Shifokorlar',value:dashboardStats?.doctors ?? doctors.length,note:'Bazadagi jami',icon:'doctor',tone:'blue',to:'doctors'},{label:'Bemorlar',value:dashboardStats?.patients ?? patients.length,note:'Bazadagi jami',icon:'users',tone:'green',to:'patients'},{label:'Bugungi uchrashuvlar',value:todayAppointments.length,note:'Bugungi jami',icon:'calendar',tone:'purple',to:'appointments'},{label:'Bo‘limlar',value:dashboardStats?.departments ?? departments.length,note:'Bazadagi jami',icon:'hospital',tone:'pink',to:'departments'}].map(card=><button key={card.label} className={`ref-stat ${card.tone}`} onClick={()=>goTo(card.to)}><span className="ref-stat-icon"><Icon name={card.icon} size={24}/></span><span className="ref-stat-copy"><small>{card.label}</small><strong>{card.value}</strong><em>{card.note}</em></span></button>)}
              </div>

              <div className="ref-main-grid">
                <article className="ref-panel ref-chart-panel">
                  <div className="ref-panel-head"><div><h3>Uchrashuvlar statistikasi</h3><p>Joriy haftadagi saqlangan uchrashuvlar</p></div><div className="ref-legend"><span><i className="blue-dot"/>Uchrashuvlar</span></div></div>
                  <div className="real-week-chart" aria-label="Joriy hafta uchrashuvlari">{weeklyAppointmentCounts.map((day) => <div className="real-week-day" key={day.key} title={`${day.key}: ${day.count} ta`}><strong>{day.count}</strong><div className="real-week-track"><i style={{ height: `${Math.max(5, (day.count / Math.max(1, ...weeklyAppointmentCounts.map((item) => item.count))) * 100)}%` }} /></div><span>{day.label}</span></div>)}</div>
                </article>

                <article className="ref-panel dept-chart-panel"><div className="ref-panel-head"><h3>Bo‘limlar bo‘yicha uchrashuvlar</h3></div><div className="donut-row"><div className="donut" style={deptStats.bg ? { background: deptStats.bg } : undefined}><div><b>{deptStats.total}</b><span>Jami uchrashuv</span></div></div><div className="dept-legend">{deptStats.rows.length ? deptStats.rows.map((r) => <div className="dl-row" key={r.name}><i style={{ background: r.color }} /><span>{r.name}</span><b>{r.count}</b><em>{r.pct}%</em></div>) : <p className="ref-empty">Hozircha uchrashuvlar yo‘q.</p>}</div></div><div className="status-strip"><span className="ss ss-sched"><Icon name="calendar" size={14} />Scheduled <b>{deptStats.status.Scheduled}</b></span><span className="ss ss-wait"><Icon name="hourglass" size={14} />Pending <b>{deptStats.status.Pending}</b></span><span className="ss ss-done"><Icon name="check" size={14} />Completed <b>{deptStats.status.Completed}</b></span><span className="ss ss-cancel"><Icon name="close" size={14} />Cancelled <b>{deptStats.status.Cancelled}</b></span></div></article>
              </div>

              <div className="ref-bottom-grid">
                <article className="ref-panel recent-panel"><div className="ref-panel-head"><h3>So‘nggi uchrashuvlar</h3><button onClick={()=>goTo('appointments')}>Barchasini ko‘rish <Icon name="arrow" size={13}/></button></div><div className="appt-list">{appointments.slice(0,5).map((a,i)=>{const st=apptStatus(a.status);const dp=dayParts(a.date);const pn=a.patient?.name||a.patientName||(typeof a.patient==='string'?a.patient:'Bemor');const dn=a.doctor?.name||a.doctorName||(typeof a.doctor==='string'?a.doctor:'Shifokor');return <div className="appt-card" key={a._id||a.id||i}><div className="appt-date"><b>{dp.d}</b><span>{dp.m}</span></div><div className="appt-body"><div className="appt-patient"><i className={`mini-avatar av${i%4}`}>{initials(pn,'P')}</i><div><strong>{pn}</strong><small>{a.reason||'Sabab ko‘rsatilmagan'}</small></div></div><div className="appt-meta"><span className="appt-chip"><Icon name="doctor" size={14}/>{dn}</span><span className="appt-chip"><Icon name="clock" size={14}/>{a.time||'—'}</span></div></div><span className={`appt-status st-${st.cls}`}><Icon name={st.icon} size={14}/>{st.label}</span></div>})}{!appointments.length&&<div className="ref-empty">Hozircha uchrashuvlar yo‘q.</div>}</div></article>
                <article className="ref-panel doctors-panel"><div className="ref-panel-head"><h3>Shifokorlar</h3><button onClick={()=>goTo('doctors')}>Barchasini ko‘rish <Icon name="arrow" size={13}/></button></div><div className="doc-list">{(doctors.length?doctors:[]).slice(0,6).map((d,i)=><div className="doc-card" key={d._id||d.id||i}><div className="doc-av"><i className={`doctor-avatar da${i%4}`}>{initials(d.name,'D')}</i><span className="doc-dot"/></div><div className="doc-info"><b>{d.name}</b><span className="doc-spec"><Icon name="doctor" size={12}/>{d.specialty||'Mutaxassis'}</span></div><em className="doc-status">Faol</em></div>)}</div>{!doctors.length&&<div className="ref-empty">Hozircha shifokor yo‘q. ‘Add Doctor’ orqali qo‘shing.</div>}</article>
                <article className="ref-panel quick-panel"><h3>Tezkor amallar</h3><button className="q-blue" onClick={()=>goTo('patients')}><Icon name="plus"/>Yangi bemor</button><button className="q-green" onClick={openCreateDoctor}><Icon name="plus"/>Yangi shifokor</button><button className="q-purple" onClick={()=>goTo('appointments')}><Icon name="plus"/>Yangi uchrashuv</button><button className="q-orange" onClick={()=>goTo('departments')}><Icon name="plus"/>Yangi bo‘lim</button><div className="system-ok"><Icon name="check" size={22}/><div><b>MedCare boshqaruvi</b><span>Ma’lumotlar bazaga saqlanadi.</span></div></div></article>
              </div>
            </section>
          )}

          {page === "doctors" && (
            <section className="page-section">
              <div className="page-header"><div><span className="eyebrow dark">MEDICAL TEAM</span><h2>Doctors</h2><p>Manage doctors and their hospital departments.</p></div><button className="primary-button" onClick={openCreateDoctor}><Icon name="plus" size={16} /> Add Doctor</button></div>
              <div className="table-toolbar"><div className="search-box"><Icon name="search" size={16} /><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search doctors..." /></div><span className="result-count">{filteredDoctors.length} doctors</span></div>
              <div className="table-card panel"><div className="table-wrapper">{loading ? <div className="loading-state">Loading doctors...</div> : filteredDoctors.length === 0 ? <div className="empty-state"><Icon name="doctor" size={28} /><h3>No doctors found</h3><p>Add your first doctor to get started.</p><button className="primary-button" onClick={openCreateDoctor}>Add Doctor</button></div> : <table className="tbl-doctors"><thead><tr><th>Doctor</th><th>Email</th><th>Phone</th><th>Specialty</th><th>Department</th><th>Actions</th></tr></thead><tbody>{filteredDoctors.map((doctor) => { const id = doctor._id || doctor.id; return <tr key={id}><td><div className="table-person"><div className="person-avatar">{initials(doctor.name, "D")}</div><strong>{doctor.name || "Unknown"}</strong></div></td><td>{doctor.email || "-"}</td><td>{doctor.phone || "-"}</td><td>{doctor.specialty || doctor.specialization || "-"}</td><td>{doctor.department || "-"}</td><td><div className="table-actions"><button className="edit-button" onClick={() => openEditDoctor(doctor)}><Icon name="edit" size={14} /> Edit</button><button className="delete-button" onClick={() => handleDeleteDoctor(id)}><Icon name="trash" size={14} /> Delete</button></div></td></tr>; })}</tbody></table>}</div></div>
            </section>
          )}

          {page === "patients" && <Patient globalSearch={search} />}
          {page === "appointments" && <Appointment globalSearch={search} />}
          {page === "departments" && <Department globalSearch={search} />}
        </div>
      </main>

      {settingsOpen && <div className="modal-overlay" onClick={() => setSettingsOpen(false)}><div className="modal settings-modal" onClick={(e) => e.stopPropagation()}><div className="modal-header"><div><span className="eyebrow dark">ACCOUNT</span><h2>Settings</h2><p>Manage your account and workspace preferences.</p></div><button className="modal-close" onClick={() => setSettingsOpen(false)}><Icon name="close" /></button></div><div className="settings-tabs"><button className={settingsTab === "profile" || settingsTab === "saved" ? "active" : ""} onClick={() => setSettingsTab("profile")}>Profile</button><button className={settingsTab === "preferences" ? "active" : ""} onClick={() => setSettingsTab("preferences")}>Preferences</button><button className={settingsTab === "security" ? "active" : ""} onClick={() => setSettingsTab("security")}>Security</button></div>{settingsTab === "saved" && <div className="settings-success"><Icon name="check" size={18} /><div><strong>Settings saved</strong><span>Your account information was updated successfully.</span></div></div>}{(settingsTab === "profile" || settingsTab === "saved") && <form onSubmit={saveSettings}><div className="form-grid"><div className="form-group"><label>Full name</label><input value={settingsForm.name} onChange={(e) => setSettingsForm((p) => ({ ...p, name: e.target.value }))} required /></div><div className="form-group"><label>Email address</label><input type="email" value={settingsForm.email} onChange={(e) => setSettingsForm((p) => ({ ...p, email: e.target.value }))} required /></div></div><div className="modal-footer"><button type="button" className="cancel-button" onClick={() => setSettingsOpen(false)}>Close</button><button className="primary-button" disabled={loading}><Icon name="save" size={14} /> {loading ? "Saving..." : "Save changes"}</button></div></form>}{settingsTab === "preferences" && <div className="settings-list"><div className="settings-row"><div><strong>Notifications</strong><small>Show appointment reminders and system alerts.</small></div><button type="button" className={`switch ${preferences.notifications ? "on" : ""}`} onClick={() => setPreferences((p) => ({ ...p, notifications: !p.notifications }))}><i /></button></div><div className="settings-row"><div><strong>Compact layout</strong><small>Reduce spacing to fit more information on screen.</small></div><button type="button" className={`switch ${preferences.compact ? "on" : ""}`} onClick={() => setPreferences((p) => ({ ...p, compact: !p.compact }))}><i /></button></div><div className="settings-row"><div><strong>Theme</strong><small>Choose how MedCare looks on this device.</small></div><button type="button" className="preference-button" onClick={() => setTheme((value) => value === "light" ? "dark" : "light")}>{theme === "light" ? "Light" : "Dark"}</button></div></div>}{settingsTab === "security" && <form onSubmit={saveSettings}><div className="security-note"><Icon name="lock" size={18} /><span>Password change is optional. Enter your current password and a new password.</span></div><div className="form-grid"><div className="form-group full-width"><label>Current password</label><input type="password" value={settingsForm.currentPassword} onChange={(e) => setSettingsForm((p) => ({ ...p, currentPassword: e.target.value }))} placeholder="Current password" /></div><div className="form-group full-width"><label>New password</label><input type="password" minLength={6} value={settingsForm.newPassword} onChange={(e) => setSettingsForm((p) => ({ ...p, newPassword: e.target.value }))} placeholder="At least 6 characters" /></div></div><div className="modal-footer"><button type="button" className="cancel-button" onClick={() => setSettingsOpen(false)}>Close</button><button className="primary-button" disabled={loading}><Icon name="save" size={14} /> {loading ? "Saving..." : "Update password"}</button></div></form>}</div></div>}

      {helpOpen && <div className="modal-overlay" onClick={() => setHelpOpen(false)}><div className="modal help-modal" onClick={(e) => e.stopPropagation()}><div className="modal-header"><div><span className="eyebrow dark">SUPPORT CENTER</span><h2>Help & Support</h2><p>Quick answers and a direct way to contact the MedCare team.</p></div><button className="modal-close" onClick={() => setHelpOpen(false)}><Icon name="close" /></button></div><div className="help-cards"><div className="help-card"><Icon name="activity" size={18} /><div><strong>How do I add a doctor?</strong><span>Open Doctors from the sidebar and choose Add Doctor.</span></div></div><div className="help-card"><Icon name="calendar" size={18} /><div><strong>How do appointments work?</strong><span>Open Appointments to create, edit, complete or cancel visits.</span></div></div><div className="help-card"><Icon name="settings" size={18} /><div><strong>Where are my preferences?</strong><span>Use Settings to change profile, theme, notifications and password.</span></div></div></div><div className="help-divider"><span>Contact support</span></div>{supportSent ? <div className="settings-success"><Icon name="check" size={18} /><div><strong>Message sent</strong><span>Your support request was saved to the MedCare backend.</span></div></div> : <form onSubmit={submitSupport}><div className="form-grid"><div className="form-group full-width"><label>Subject</label><input value={supportForm.subject} onChange={(e) => setSupportForm((p) => ({ ...p, subject: e.target.value }))} placeholder="What do you need help with?" required /></div><div className="form-group full-width"><label>Message</label><textarea rows="5" value={supportForm.message} onChange={(e) => setSupportForm((p) => ({ ...p, message: e.target.value }))} placeholder="Describe the problem or question..." required /></div></div><div className="modal-footer"><button type="button" className="cancel-button" onClick={() => setHelpOpen(false)}>Close</button><button className="primary-button" disabled={supportSending}><Icon name="mail" size={14} /> {supportSending ? "Sending..." : "Send to support"}</button></div></form>}</div></div>}

      {showDoctorModal && <div className="modal-overlay" onClick={() => setShowDoctorModal(false)}><div className="modal" onClick={(e) => e.stopPropagation()}><div className="modal-header"><div><span className="eyebrow dark">MEDICAL TEAM</span><h2>{editingDoctor ? "Edit Doctor" : "Add Doctor"}</h2><p>Enter doctor information.</p></div><button className="modal-close" onClick={() => setShowDoctorModal(false)}><Icon name="close" /></button></div><form onSubmit={handleDoctorSubmit}><div className="form-grid"><div className="form-group"><label>Doctor name</label><input name="name" value={doctorForm.name} onChange={(e) => setDoctorForm((p) => ({ ...p, name: e.target.value }))} placeholder="Dr. John Smith" required /></div><div className="form-group"><label>Email</label><input type="email" name="email" value={doctorForm.email} onChange={(e) => setDoctorForm((p) => ({ ...p, email: e.target.value }))} placeholder="doctor@example.com" required /></div><div className="form-group"><label>Phone</label><input name="phone" value={doctorForm.phone} onChange={(e) => setDoctorForm((p) => ({ ...p, phone: e.target.value }))} placeholder="+998 90 123 45 67" /></div><div className="form-group"><label>Specialty</label><input name="specialty" value={doctorForm.specialty} onChange={(e) => setDoctorForm((p) => ({ ...p, specialty: e.target.value }))} placeholder="Cardiology" /></div><div className="form-group full-width"><label>Department</label><input name="department" value={doctorForm.department} onChange={(e) => setDoctorForm((p) => ({ ...p, department: e.target.value }))} placeholder="Cardiology Department" /></div></div><div className="modal-footer"><button type="button" className="cancel-button" onClick={() => setShowDoctorModal(false)}>Cancel</button><button type="submit" className="primary-button" disabled={loading}>{loading ? "Saving..." : editingDoctor ? "Update Doctor" : "Add Doctor"}</button></div></form></div></div>}
    </div>
  );
}
