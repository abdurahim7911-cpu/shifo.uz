import { useState } from "react";
import { loginUser, registerUser, forgotPassword, resetPassword } from "./services/api";
import "./Login.css";


const ico = {
  mail: <><rect x="3" y="5" width="18" height="14" rx="2" /><path d="m4 7 8 6 8-6" /></>,
  user: <><circle cx="12" cy="8" r="3.5" /><path d="M5 20c.7-4 3.2-6 7-6s6.3 2 7 6" /></>,
  lock: <><rect x="5" y="10" width="14" height="10" rx="2" /><path d="M8 10V7a4 4 0 0 1 8 0v3" /></>,
  key: <><circle cx="8" cy="15" r="4" /><path d="m11 12 9-9M16 7l3 3" /></>,
  hash: <path d="M5 9h14M5 15h14M10 4 8 20M16 4l-2 16" />,
  plus: <path d="M12 5v14M5 12h14" />,
  cal: <><rect x="3" y="5" width="18" height="16" rx="2" /><path d="M16 3v4M8 3v4M3 10h18" /></>,
  check: <path d="m5 12 4 4L19 6" />,
  arrow: <path d="M5 12h14M13 6l6 6-6 6" />,
  alert: <><path d="M12 8v5M12 16.5h.01" /><circle cx="12" cy="12" r="9" /></>,
  shield: <><path d="M12 3 5 6v5c0 4.5 3 8 7 10 4-2 7-5.5 7-10V6z" /><path d="m9 12 2 2 4-4" /></>,
};
function I({ n, s = 18 }) {
  return <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{ico[n]}</svg>;
}

export default function Login({ onLogin }) {
  const [mode, setMode] = useState("login");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [code, setCode] = useState("");
  const [devCode, setDevCode] = useState("");
  const isRegister = mode === "register";
  const isForgot = mode === "forgot";
  const isReset = mode === "reset";

  function switchMode(nextMode) {
    setMode(nextMode);
    setError("");
    setSuccess("");
    setPassword("");
    setConfirmPassword("");
    setCode("");
    setDevCode("");
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setError("");
    setSuccess("");
    if (isRegister && password !== confirmPassword) {
      setError("Parollar bir xil emas.");
      return;
    }
    if (isReset && password !== confirmPassword) {
      setError("Parollar bir xil emas.");
      return;
    }
    setLoading(true);
    try {
      if (isForgot) {
        const data = await forgotPassword(email.trim());
        setSuccess(data.message);
        setDevCode(data.devCode || "");
        setMode("reset");
      } else if (isReset) {
        const data = await resetPassword(email.trim(), code.trim(), password);
        setMode("login");
        setPassword("");
        setConfirmPassword("");
        setCode("");
        setDevCode("");
        setSuccess(data.message);
      } else if (isRegister) {
        const data = await registerUser(name.trim(), email.trim(), password);
        setSuccess(data.message || "Hisob yaratildi. Endi tizimga kiring.");
        setMode("login");
        setName("");
        setPassword("");
        setConfirmPassword("");
      } else {
        const data = await loginUser(email.trim(), password);
        if (data?.user) onLogin(data.user);
        else setError("Kirish ma'lumotlari noto'g'ri.");
      }
    } catch (err) {
      setError(err.message || (isForgot || isReset ? "Parolni tiklab bo'lmadi." : isRegister ? "Ro'yxatdan o'tib bo'lmadi." : "Email yoki parol noto'g'ri."));
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="login-page">
      <div className="login-left">
        <div className="login-overlay" />
        <div className="login-left-content">
          <div className="login-brand"><div className="login-brand-icon"><I n="plus" s={26} /></div><span>Med<span>Care</span></span></div>
          <div className="login-welcome">
            <div className="welcome-badge">Hospital Management System</div>
            <h1>{isRegister ? <>Create your<br /><span>account.</span></> : <>Welcome<br /><span>back!</span></>}</h1>
            <p>Manage your hospital, doctors, patients and appointments from one simple platform.</p>
          </div>
          <div className="login-features">
            <div className="login-feature"><div><I n="user" s={20} /></div><span>Doctors & patients<small>One place for every record</small></span></div>
            <div className="login-feature"><div><I n="cal" s={20} /></div><span>Smart scheduling<small>Track every appointment</small></span></div>
            <div className="login-feature"><div><I n="shield" s={20} /></div><span>Secure workspace<small>Protected staff access</small></span></div>
          </div>
        </div>
      </div>
      <div className="login-right">
        <div className="login-card">
          <div className="mobile-brand"><div className="login-brand-icon"><I n="plus" s={26} /></div><span>Med<span>Care</span></span></div>
          <div className="login-heading">
            <div className="login-icon"><I n={isRegister ? "user" : isForgot || isReset ? "key" : "shield"} s={24} /></div>
            <h2>{isForgot ? "Forgot password" : isReset ? "Reset password" : isRegister ? "Create account" : "Sign in"}</h2>
            <p>{isForgot ? "Enter your email and we will generate a 6-digit reset code." : isReset ? "Enter the 6-digit code and choose a new password." : isRegister ? "Create your MedCare staff account to get started." : "Enter your account details to continue."}</p>
          </div>

          {error && <div className="login-error" role="alert"><div className="error-icon"><I n="alert" s={18} /></div><div><strong>{isForgot || isReset ? "Reset failed" : isRegister ? "Registration failed" : "Login failed"}</strong><p>{error}</p></div><button type="button" onClick={() => setError("")} aria-label="Close error">×</button></div>}
          {success && <div className="login-success" role="status"><strong>Success!</strong><p>{success}</p></div>}
          {devCode && <div className="login-success" role="status"><strong>Demo code: {devCode}</strong><p>Real email is not connected, so the code is shown here for the demo.</p></div>}

          <form className="login-form" onSubmit={handleSubmit}>
            {isRegister && <div className="login-field"><label htmlFor="signup-name">Full name</label><div className="input-wrapper"><span className="input-icon"><I n="user" /></span><input id="signup-name" type="text" autoComplete="name" value={name} onChange={(e) => setName(e.target.value)} placeholder="Your full name" maxLength={100} required /></div></div>}
            <div className="login-field"><label htmlFor="account-email">Email address</label><div className="input-wrapper"><span className="input-icon"><I n="mail" /></span><input id="account-email" type="email" autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" readOnly={isReset} required /></div></div>
            {isReset && <div className="login-field"><label htmlFor="reset-code">6-digit code</label><div className="input-wrapper"><span className="input-icon"><I n="hash" /></span><input id="reset-code" type="text" inputMode="numeric" autoComplete="one-time-code" value={code} onChange={(e) => setCode(e.target.value.replace(/\D/g, "").slice(0, 6))} placeholder="123456" minLength={6} maxLength={6} required /></div></div>}
            {!isForgot && <div className="login-field"><div className="password-label"><label htmlFor="account-password">{isReset ? "New password" : "Password"}</label>{!isRegister && !isReset && <button type="button" className="forgot-link" onClick={() => switchMode("forgot")}>Forgot password?</button>}</div><div className="input-wrapper"><span className="input-icon"><I n="lock" /></span><input id="account-password" type={showPassword ? "text" : "password"} autoComplete={isRegister ? "new-password" : "current-password"} value={password} onChange={(e) => setPassword(e.target.value)} placeholder={isRegister ? "At least 6 characters" : "Enter your password"} minLength={6} maxLength={128} required /><button type="button" className="password-toggle" onClick={() => setShowPassword((v) => !v)}>{showPassword ? "Hide" : "Show"}</button></div></div>}
            {(isRegister || isReset) && <div className="login-field"><label htmlFor="confirm-password">Confirm password</label><div className="input-wrapper"><span className="input-icon"><I n="lock" /></span><input id="confirm-password" type={showPassword ? "text" : "password"} autoComplete="new-password" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} placeholder="Repeat your password" minLength={6} maxLength={128} required /></div></div>}
            <button type="submit" className="login-button" disabled={loading}>{loading ? <><span className="button-spinner" />{isForgot ? "Sending..." : isReset ? "Saving..." : isRegister ? "Creating account..." : "Signing in..."}</> : <>{isForgot ? "Send reset code" : isReset ? "Reset password" : isRegister ? "Create account" : "Sign in"}<span className="button-arrow"><I n="arrow" s={18} /></span></>}</button>
          </form>
          <div className="auth-switch">{isForgot || isReset ? <>Remembered it? <button type="button" onClick={() => switchMode("login")}>Back to sign in</button></> : <>{isRegister ? "Already have an account?" : "Don't have an account?"} <button type="button" onClick={() => switchMode(isRegister ? "login" : "register")}>{isRegister ? "Sign in" : "Sign up"}</button></>}</div>
          <p className="login-footer">© 2026 MedCare Hospital Management System</p>
        </div>
      </div>
    </div>
  );
}
