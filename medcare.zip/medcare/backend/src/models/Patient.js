const mongoose = require("mongoose");

const patientSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    email: { type: String, default: "", trim: true, lowercase: true },
    phone: { type: String, default: "", trim: true },
    age: { type: Number, min: 0, max: 130 },
    dateOfBirth: { type: String, default: "" },
    gender: { type: String, default: "", trim: true },
    address: { type: String, default: "", trim: true },
    bloodGroup: { type: String, default: "", trim: true },
    status: { type: String, enum: ["Active", "Inactive"], default: "Active" },
  },
  { timestamps: true }
);

module.exports = mongoose.model("Patient", patientSchema);
