const mongoose = require("mongoose");

const userSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
      trim: true,
    },

    email: {
      type: String,
      required: true,
      unique: true,
      trim: true,
      lowercase: true,
    },

    password: {
      type: String,
      required: true,
      minlength: 6,
    },

    resetCodeHash: { type: String, default: "" },
    resetCodeExpires: { type: Date, default: null },
    resetAttempts: { type: Number, default: 0 },

    role: {
      type: String,
      enum: ["Admin", "Doctor", "Staff"],
      default: "Admin",
    },
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.model("User", userSchema);