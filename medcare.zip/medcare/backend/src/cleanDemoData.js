const path = require("path");
const dotenv = require("dotenv");
const mongoose = require("mongoose");
const connectDB = require("./config/db");
const Doctor = require("./models/Doctor");
const Patient = require("./models/Patient");
const Appointment = require("./models/Appointment");

dotenv.config({ path: path.join(__dirname, "..", ".env") });

// Faqat avvalgi demo ma'lumotlarining aniq email manzillari o'chiriladi.
// Boshqa shifokorlar/bemorlar va admin akkaunti saqlanib qoladi.
const demoDoctorEmails = [
  "aziz.karimov@medcare.com",
  "malika.tursunova@medcare.com",
  "bekzod.rahimov@medcare.com",
  "nilufar.sattorova@medcare.com",
  "jamshid.alimov@medcare.com",
  "dilnoza.qodirova@medcare.com",
];

const demoPatientEmails = [
  "muhammad.aliyev@example.com",
  "madina.ismoilova@example.com",
  "sardor.yusupov@example.com",
  "zarina.abdullayeva@example.com",
  "javohir.ergashev@example.com",
  "sevara.raxmatova@example.com",
];

async function cleanDemoData() {
  try {
    await connectDB();

    const [doctors, patients] = await Promise.all([
      Doctor.find({ email: { $in: demoDoctorEmails } }).select("_id email"),
      Patient.find({ email: { $in: demoPatientEmails } }).select("_id email"),
    ]);

    const doctorIds = doctors.map((item) => item._id);
    const patientIds = patients.map((item) => item._id);

    const appointmentResult = await Appointment.deleteMany({
      $or: [
        ...(doctorIds.length ? [{ doctor: { $in: doctorIds } }] : []),
        ...(patientIds.length ? [{ patient: { $in: patientIds } }] : []),
      ],
    });

    const [doctorResult, patientResult] = await Promise.all([
      Doctor.deleteMany({ _id: { $in: doctorIds } }),
      Patient.deleteMany({ _id: { $in: patientIds } }),
    ]);

    console.log("Demo ma'lumotlari tozalandi:");
    console.log(`Shifokorlar: ${doctorResult.deletedCount}`);
    console.log(`Bemorlar: ${patientResult.deletedCount}`);
    console.log(`Uchrashuvlar: ${appointmentResult.deletedCount}`);
    console.log("Boshqa ma'lumotlar va admin akkaunti o'chirilmadi.");
  } catch (error) {
    console.error("Demo ma'lumotlarini tozalashda xatolik:", error.message);
    process.exitCode = 1;
  } finally {
    await mongoose.connection.close();
  }
}

cleanDemoData();
