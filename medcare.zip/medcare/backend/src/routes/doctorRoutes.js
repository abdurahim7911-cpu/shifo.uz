const express = require("express");
const router = express.Router();

const Doctor = require("../models/Doctor");
const Appointment = require("../models/Appointment");

// ==================== GET ALL DOCTORS ====================

router.get("/", async (req, res) => {
  try {
    const doctors = await Doctor.find().sort({ createdAt: -1 });

    res.status(200).json(doctors);
  } catch (error) {
    console.error("GET DOCTORS ERROR:", error);

    res.status(500).json({
      message: "Doctorlarni olishda xatolik",
      error: error.message,
    });
  }
});

// ==================== GET DOCTOR BY ID ====================

router.get("/:id", async (req, res) => {
  try {
    const doctor = await Doctor.findById(req.params.id);

    if (!doctor) {
      return res.status(404).json({
        message: "Doctor topilmadi",
      });
    }

    res.status(200).json(doctor);
  } catch (error) {
    console.error("GET DOCTOR ERROR:", error);

    res.status(500).json({
      message: "Doctorni olishda xatolik",
      error: error.message,
    });
  }
});

// ==================== CREATE DOCTOR ====================

router.post("/", async (req, res) => {
  try {
    const { name, specialty, email, phone, department, status } = req.body;

    if (!name || !specialty || !email) {
      return res.status(400).json({
        message: "Name, specialty va email majburiy",
      });
    }

    const existingDoctor = await Doctor.findOne({ email });

    if (existingDoctor) {
      return res.status(400).json({
        message: "Bu email bilan doctor allaqachon mavjud",
      });
    }

    const doctor = await Doctor.create({
      name,
      specialty,
      email,
      phone: phone || "",
      department: department || "",
      status: status || "Active",
    });

    res.status(201).json(doctor);
  } catch (error) {
    console.error("CREATE DOCTOR ERROR:", error);

    res.status(500).json({
      message: "Doctor yaratishda xatolik",
      error: error.message,
    });
  }
});

// ==================== UPDATE DOCTOR ====================

router.put("/:id", async (req, res) => {
  try {
    const { name, specialty, email, phone, department, status } = req.body;

    const doctor = await Doctor.findById(req.params.id);

    if (!doctor) {
      return res.status(404).json({
        message: "Doctor topilmadi",
      });
    }

    if (email && email !== doctor.email) {
      const existingDoctor = await Doctor.findOne({
        email,
        _id: { $ne: req.params.id },
      });

      if (existingDoctor) {
        return res.status(400).json({
          message: "Bu email boshqa doctor uchun ishlatilgan",
        });
      }
    }

    doctor.name = name ?? doctor.name;
    doctor.specialty = specialty ?? doctor.specialty;
    doctor.email = email ?? doctor.email;
    doctor.phone = phone ?? doctor.phone;
    doctor.department = department ?? doctor.department;
    doctor.status = status ?? doctor.status;

    const updatedDoctor = await doctor.save();

    res.status(200).json(updatedDoctor);
  } catch (error) {
    console.error("UPDATE DOCTOR ERROR:", error);

    res.status(500).json({
      message: "Doctorni yangilashda xatolik",
      error: error.message,
    });
  }
});

// ==================== DELETE DOCTOR ====================

router.delete("/:id", async (req, res) => {
  try {
    const doctor = await Doctor.findById(req.params.id);

    if (!doctor) {
      return res.status(404).json({
        message: "Doctor topilmadi",
      });
    }

    await Doctor.findByIdAndDelete(req.params.id);
    await Appointment.deleteMany({ doctor: req.params.id });

    res.status(200).json({
      message: "Doctor muvaffaqiyatli o'chirildi",
      id: req.params.id,
    });
  } catch (error) {
    console.error("DELETE DOCTOR ERROR:", error);

    res.status(500).json({
      message: "Doctorni o'chirishda xatolik",
      error: error.message,
    });
  }
});

module.exports = router;