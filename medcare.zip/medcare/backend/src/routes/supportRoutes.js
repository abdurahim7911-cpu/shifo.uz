const express = require("express");
const { createTicket, getTickets } = require("../controllers/supportController");

const router = express.Router();
router.post("/tickets", createTicket);
router.get("/tickets", getTickets);
module.exports = router;
