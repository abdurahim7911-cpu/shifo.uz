const express = require("express");

const {
  loginUser,
  createUser,
  getProfile,
  updateProfile,
  forgotPassword,
  resetPassword,
} = require("../controllers/authController");

const router = express.Router();

router.post("/login", loginUser);
router.post("/register", createUser);
router.post("/forgot-password", forgotPassword);
router.post("/reset-password", resetPassword);
router.get("/profile/:id", getProfile);
router.put("/profile/:id", updateProfile);

module.exports = router;