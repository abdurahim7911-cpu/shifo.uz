const express = require("express");

const {
  getAppointments,
  getAppointmentById,
  createAppointment,
  updateAppointment,
  deleteAppointment,
} = require("../controllers/appointmentController");

const router = express.Router();

// GET all appointments
router.get("/", getAppointments);

// GET appointment by ID
router.get("/:id", getAppointmentById);

// CREATE appointment
router.post("/", createAppointment);

// UPDATE appointment
router.put("/:id", updateAppointment);

// DELETE appointment
router.delete("/:id", deleteAppointment);

module.exports = router;