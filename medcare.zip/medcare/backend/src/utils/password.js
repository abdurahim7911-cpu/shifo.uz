const crypto = require("crypto");
const { promisify } = require("util");
const scrypt = promisify(crypto.scrypt);

async function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString("hex");
  const derivedKey = await scrypt(password, salt, 64);
  return `scrypt:${salt}:${derivedKey.toString("hex")}`;
}

async function verifyPassword(password, storedPassword) {
  // Keep compatibility with accounts created before password hashing was added.
  if (!storedPassword || !storedPassword.startsWith("scrypt:")) {
    return password === storedPassword;
  }
  const [, salt, key] = storedPassword.split(":");
  if (!salt || !key) return false;
  const derivedKey = await scrypt(password, salt, 64);
  const expected = Buffer.from(key, "hex");
  return expected.length === derivedKey.length && crypto.timingSafeEqual(expected, derivedKey);
}

module.exports = { hashPassword, verifyPassword };
