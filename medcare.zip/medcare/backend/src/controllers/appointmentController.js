const Appointment = require("../models/Appointment");

// ==================== GET ALL APPOINTMENTS ====================

const getAppointments = async (req, res) => {
  try {
    const appointments = await Appointment.find()
      .populate("patient", "name email phone")
      .populate("doctor", "name specialty");

    res.status(200).json(appointments);
  } catch (error) {
    console.error("Get appointments error:", error);
    res.status(500).json({
      message: "Appointmentlarni olishda xatolik",
      error: error.message,
    });
  }
};

// ==================== GET APPOINTMENT BY ID ====================

const getAppointmentById = async (req, res) => {
  try {
    const appointment = await Appointment.findById(req.params.id)
      .populate("patient", "name email phone")
      .populate("doctor", "name specialty");

    if (!appointment) {
      return res.status(404).json({
        message: "Appointment topilmadi",
      });
    }

    res.status(200).json(appointment);
  } catch (error) {
    console.error("Get appointment error:", error);

    res.status(500).json({
      message: "Appointmentni olishda xatolik",
      error: error.message,
    });
  }
};

// ==================== CREATE APPOINTMENT ====================

const createAppointment = async (req, res) => {
  try {
    const {
      patient,
      doctor,
      date,
      time,
      reason,
      status,
    } = req.body;

    if (!patient || !doctor || !date || !time) {
      return res.status(400).json({
        message: "Patient, doctor, date va time majburiy",
      });
    }

    const appointment = await Appointment.create({
      patient,
      doctor,
      date,
      time,
      reason: reason || "",
      status: status || "Scheduled",
    });

    const populatedAppointment = await Appointment.findById(
      appointment._id
    )
      .populate("patient", "name email phone")
      .populate("doctor", "name specialty");

    res.status(201).json(populatedAppointment);
  } catch (error) {
    console.error("Create appointment error:", error);

    res.status(500).json({
      message: "Appointment yaratishda xatolik",
      error: error.message,
    });
  }
};

// ==================== UPDATE APPOINTMENT ====================

const updateAppointment = async (req, res) => {
  try {
    const {
      patient,
      doctor,
      date,
      time,
      reason,
      status,
    } = req.body;

    const appointment = await Appointment.findById(req.params.id);

    if (!appointment) {
      return res.status(404).json({
        message: "Appointment topilmadi",
      });
    }

    appointment.patient = patient || appointment.patient;
    appointment.doctor = doctor || appointment.doctor;
    appointment.date = date || appointment.date;
    appointment.time = time || appointment.time;
    appointment.reason =
      reason !== undefined ? reason : appointment.reason;
    appointment.status = status || appointment.status;

    await appointment.save();

    const updatedAppointment = await Appointment.findById(
      appointment._id
    )
      .populate("patient", "name email phone")
      .populate("doctor", "name specialty");

    res.status(200).json(updatedAppointment);
  } catch (error) {
    console.error("Update appointment error:", error);

    res.status(500).json({
      message: "Appointmentni yangilashda xatolik",
      error: error.message,
    });
  }
};

// ==================== DELETE APPOINTMENT ====================

const deleteAppointment = async (req, res) => {
  try {
    const appointment = await Appointment.findById(req.params.id);

    if (!appointment) {
      return res.status(404).json({
        message: "Appointment topilmadi",
      });
    }

    await Appointment.findByIdAndDelete(req.params.id);

    res.status(200).json({
      message: "Appointment o'chirildi",
    });
  } catch (error) {
    console.error("Delete appointment error:", error);

    res.status(500).json({
      message: "Appointmentni o'chirishda xatolik",
      error: error.message,
    });
  }
};

module.exports = {
  getAppointments,
  getAppointmentById,
  createAppointment,
  updateAppointment,
  deleteAppointment,
};