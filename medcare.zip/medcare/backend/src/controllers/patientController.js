const Patient = require("../models/Patient");
const Appointment = require("../models/Appointment");

// GET /api/patients
const getPatients = async (req, res) => {
  try {
    const q = String(req.query.q || "").trim();
    const filter = q ? { $or: [
      { name: { $regex: q, $options: "i" } },
      { email: { $regex: q, $options: "i" } },
      { phone: { $regex: q, $options: "i" } },
    ] } : {};
    const patients = await Patient.find(filter).sort({
      createdAt: -1,
    });

    res.json(patients);
  } catch (error) {
    res.status(500).json({
      message: "Patientlarni olishda xatolik",
      error: error.message,
    });
  }
};

// GET /api/patients/:id
const getPatientById = async (req, res) => {
  try {
    const patient = await Patient.findById(req.params.id);

    if (!patient) {
      return res.status(404).json({
        message: "Patient topilmadi",
      });
    }

    res.json(patient);
  } catch (error) {
    res.status(500).json({
      message: "Patientni olishda xatolik",
      error: error.message,
    });
  }
};

// POST /api/patients
const createPatient = async (req, res) => {
  try {
    const patient = await Patient.create(req.body);

    res.status(201).json(patient);
  } catch (error) {
    res.status(400).json({
      message: "Patient yaratishda xatolik",
      error: error.message,
    });
  }
};

// PUT /api/patients/:id
const updatePatient = async (req, res) => {
  try {
    const patient = await Patient.findByIdAndUpdate(
      req.params.id,
      req.body,
      {
        new: true,
        runValidators: true,
      }
    );

    if (!patient) {
      return res.status(404).json({
        message: "Patient topilmadi",
      });
    }

    res.json(patient);
  } catch (error) {
    res.status(400).json({
      message: "Patientni yangilashda xatolik",
      error: error.message,
    });
  }
};

// DELETE /api/patients/:id
const deletePatient = async (req, res) => {
  try {
    const patient = await Patient.findByIdAndDelete(
      req.params.id
    );

    if (!patient) {
      return res.status(404).json({
        message: "Patient topilmadi",
      });
    }

    await Appointment.deleteMany({ patient: req.params.id });

    res.json({
      message: "Patient o'chirildi",
    });
  } catch (error) {
    res.status(500).json({
      message: "Patientni o'chirishda xatolik",
      error: error.message,
    });
  }
};

module.exports = {
  getPatients,
  getPatientById,
  createPatient,
  updatePatient,
  deletePatient,
};