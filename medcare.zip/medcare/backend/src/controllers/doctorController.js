const Doctor = require("../models/Doctor");
const Appointment = require("../models/Appointment");

const getDoctors = async (req, res) => {
  try {
    const q = String(req.query.q || "").trim();
    const filter = q ? { $or: [
      { name: { $regex: q, $options: "i" } },
      { email: { $regex: q, $options: "i" } },
      { phone: { $regex: q, $options: "i" } },
      { specialty: { $regex: q, $options: "i" } },
      { department: { $regex: q, $options: "i" } },
    ] } : {};
    const doctors = await Doctor.find(filter).sort({ createdAt: -1 });

    res.json(doctors);
  } catch (error) {
    res.status(500).json({
      message: "Doctorlarni olishda xatolik",
      error: error.message,
    });
  }
};

const getDoctorById = async (req, res) => {
  try {
    const doctor = await Doctor.findById(req.params.id);

    if (!doctor) {
      return res.status(404).json({
        message: "Doctor topilmadi",
      });
    }

    res.json(doctor);
  } catch (error) {
    res.status(500).json({
      message: "Doctorni olishda xatolik",
      error: error.message,
    });
  }
};

const createDoctor = async (req, res) => {
  try {
    const doctor = await Doctor.create(req.body);

    res.status(201).json(doctor);
  } catch (error) {
    res.status(400).json({
      message: "Doctor yaratishda xatolik",
      error: error.message,
    });
  }
};

const updateDoctor = async (req, res) => {
  try {
    const doctor = await Doctor.findByIdAndUpdate(
      req.params.id,
      req.body,
      {
        new: true,
        runValidators: true,
      }
    );

    if (!doctor) {
      return res.status(404).json({
        message: "Doctor topilmadi",
      });
    }

    res.json(doctor);
  } catch (error) {
    res.status(400).json({
      message: "Doctorni yangilashda xatolik",
      error: error.message,
    });
  }
};

const deleteDoctor = async (req, res) => {
  try {
    const doctor = await Doctor.findByIdAndDelete(req.params.id);

    if (!doctor) {
      return res.status(404).json({
        message: "Doctor topilmadi",
      });
    }

    await Appointment.deleteMany({ doctor: req.params.id });

    res.json({
      message: "Doctor o'chirildi",
    });
  } catch (error) {
    res.status(500).json({
      message: "Doctorni o'chirishda xatolik",
      error: error.message,
    });
  }
};

module.exports = {
  getDoctors,
  getDoctorById,
  createDoctor,
  updateDoctor,
  deleteDoctor,
};