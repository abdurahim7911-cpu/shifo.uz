const SupportTicket = require("../models/SupportTicket");

const createTicket = async (req, res) => {
  try {
    const { userId, name, email, subject, message } = req.body;
    if (!name || !email || !subject || !message) {
      return res.status(400).json({ message: "Name, email, subject va message majburiy" });
    }
    const ticket = await SupportTicket.create({ userId: userId || undefined, name, email, subject, message });
    res.status(201).json({ message: "Support so'rovi yuborildi", ticket });
  } catch (error) {
    console.error("Support ticket error:", error);
    res.status(500).json({ message: "Support so'rovini yuborishda xatolik", error: error.message });
  }
};

const getTickets = async (req, res) => {
  try {
    const tickets = await SupportTicket.find().sort({ createdAt: -1 }).limit(100);
    res.json({ tickets });
  } catch (error) {
    res.status(500).json({ message: "Support so'rovlarini olishda xatolik", error: error.message });
  }
};

module.exports = { createTicket, getTickets };
