const User = require("../models/User");
const crypto = require("crypto");
const { hashPassword, verifyPassword } = require("../utils/password");

function safeUser(user) {
  return { id: user._id, name: user.name, email: user.email, role: user.role };
}

const loginUser = async (req, res) => {
  try {
    const email = String(req.body.email || "").trim().toLowerCase();
    const password = String(req.body.password || "");
    if (!email || !password) return res.status(400).json({ message: "Email va parol majburiy" });

    const user = await User.findOne({ email });
    if (!user || !(await verifyPassword(password, user.password))) {
      return res.status(401).json({ message: "Email yoki parol noto'g'ri" });
    }

    // Upgrade older plain-text passwords to a secure hash after a successful login.
    if (!String(user.password).startsWith("scrypt:")) {
      user.password = await hashPassword(password);
      await user.save();
    }

    return res.status(200).json({ message: "Kirish muvaffaqiyatli", user: safeUser(user) });
  } catch (error) {
    console.error("Login error:", error);
    return res.status(500).json({ message: "Kirishda xatolik yuz berdi" });
  }
};

// Public self-registration always creates a regular Staff account. Clients cannot choose Admin.
const createUser = async (req, res) => {
  try {
    const name = String(req.body.name || "").trim();
    const email = String(req.body.email || "").trim().toLowerCase();
    const password = String(req.body.password || "");

    if (!name || !email || !password) return res.status(400).json({ message: "Ism, email va parol majburiy" });
    if (name.length > 100) return res.status(400).json({ message: "Ism juda uzun" });
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ message: "Email manzili noto'g'ri" });
    if (password.length < 6) return res.status(400).json({ message: "Parol kamida 6 ta belgidan iborat bo'lsin" });
    if (password.length > 128) return res.status(400).json({ message: "Parol juda uzun" });

    const existingUser = await User.findOne({ email });
    if (existingUser) return res.status(409).json({ message: "Bu email allaqachon ro'yxatdan o'tgan" });

    const user = await User.create({ name, email, password: await hashPassword(password), role: "Staff" });
    return res.status(201).json({ message: "Ro'yxatdan o'tish muvaffaqiyatli", user: safeUser(user) });
  } catch (error) {
    if (error.code === 11000) return res.status(409).json({ message: "Bu email allaqachon ro'yxatdan o'tgan" });
    console.error("Register error:", error);
    return res.status(500).json({ message: "Ro'yxatdan o'tishda xatolik yuz berdi" });
  }
};

const getProfile = async (req, res) => {
  try {
    const user = await User.findById(req.params.id).select("-password");
    if (!user) return res.status(404).json({ message: "Foydalanuvchi topilmadi" });
    return res.json({ user: safeUser(user) });
  } catch (error) {
    return res.status(500).json({ message: "Profilni olishda xatolik" });
  }
};

const updateProfile = async (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body;
    const name = String(req.body.name || "").trim();
    const email = String(req.body.email || "").trim().toLowerCase();
    const user = await User.findById(req.params.id);
    if (!user) return res.status(404).json({ message: "Foydalanuvchi topilmadi" });
    if (!name || !email) return res.status(400).json({ message: "Ism va email majburiy" });
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ message: "Email manzili noto'g'ri" });

    if (email !== user.email) {
      const exists = await User.findOne({ email, _id: { $ne: user._id } });
      if (exists) return res.status(409).json({ message: "Bu email allaqachon mavjud" });
    }
    if (newPassword) {
      if (!(await verifyPassword(String(currentPassword || ""), user.password))) return res.status(400).json({ message: "Joriy parol noto'g'ri" });
      if (String(newPassword).length < 6) return res.status(400).json({ message: "Yangi parol kamida 6 ta belgidan iborat bo'lsin" });
      user.password = await hashPassword(String(newPassword));
    }
    user.name = name;
    user.email = email;
    await user.save();
    return res.json({ message: "Profil saqlandi", user: safeUser(user) });
  } catch (error) {
    if (error.code === 11000) return res.status(409).json({ message: "Bu email allaqachon mavjud" });
    console.error("Profile update error:", error);
    return res.status(500).json({ message: "Profilni saqlashda xatolik" });
  }
};

const sha256 = (v) => crypto.createHash("sha256").update(v).digest("hex");

// Step 1: ask for a 6-digit reset code. The response is always the same, so it does not reveal which emails exist.
// No email service is configured, so the code is printed in the BACKEND console (development use only).
const forgotPassword = async (req, res) => {
  try {
    const email = String(req.body.email || "").trim().toLowerCase();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ message: "Email manzili noto'g'ri" });
    const user = await User.findOne({ email });
    if (user) {
      const code = String(crypto.randomInt(100000, 1000000));
      user.resetCodeHash = sha256(code);
      user.resetCodeExpires = new Date(Date.now() + 15 * 60 * 1000);
      user.resetAttempts = 0;
      await user.save();
      console.log(`[PAROLNI TIKLASH] ${email} uchun kod: ${code} (15 daqiqa amal qiladi)`);
    }
    return res.json({ message: "Agar bu email ro'yxatdan o'tgan bo'lsa, tiklash kodi yuborildi." });
  } catch (error) {
    console.error("Forgot password error:", error);
    return res.status(500).json({ message: "Kod yaratishda xatolik" });
  }
};

// Step 2: check the code and set the new password.
const resetPassword = async (req, res) => {
  try {
    const email = String(req.body.email || "").trim().toLowerCase();
    const code = String(req.body.code || "").trim();
    const newPassword = String(req.body.newPassword || "");
    if (!email || !code || !newPassword) return res.status(400).json({ message: "Email, kod va yangi parol majburiy" });
    if (newPassword.length < 6) return res.status(400).json({ message: "Yangi parol kamida 6 ta belgidan iborat bo'lsin" });
    if (newPassword.length > 128) return res.status(400).json({ message: "Parol juda uzun" });

    const user = await User.findOne({ email });
    const invalid = { message: "Kod noto'g'ri yoki muddati tugagan" };
    if (!user || !user.resetCodeHash || !user.resetCodeExpires || user.resetCodeExpires < new Date()) return res.status(400).json(invalid);
    if (user.resetAttempts >= 5) {
      user.resetCodeHash = ""; user.resetCodeExpires = null; await user.save();
      return res.status(429).json({ message: "Juda ko'p urinish. Yangi kod so'rang." });
    }
    const a = Buffer.from(sha256(code)), b = Buffer.from(user.resetCodeHash);
    if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
      user.resetAttempts += 1; await user.save();
      return res.status(400).json(invalid);
    }
    user.password = await hashPassword(newPassword);
    user.resetCodeHash = ""; user.resetCodeExpires = null; user.resetAttempts = 0;
    await user.save();
    return res.json({ message: "Parol yangilandi. Endi yangi parol bilan kiring." });
  } catch (error) {
    console.error("Reset password error:", error);
    return res.status(500).json({ message: "Parolni yangilashda xatolik" });
  }
};

module.exports = { loginUser, createUser, getProfile, updateProfile, forgotPassword, resetPassword };
