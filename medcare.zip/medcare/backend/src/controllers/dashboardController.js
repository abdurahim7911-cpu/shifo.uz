const Doctor = require("../models/Doctor");
const Patient = require("../models/Patient");
const Appointment = require("../models/Appointment");
const Department = require("../models/Department");

async function getDashboardStats(req, res) {
  try {
    const [doctors, patients, appointments, departments, scheduled, completed, cancelled] = await Promise.all([
      Doctor.countDocuments(),
      Patient.countDocuments(),
      Appointment.countDocuments(),
      Department.countDocuments(),
      Appointment.countDocuments({ status: "Scheduled" }),
      Appointment.countDocuments({ status: "Completed" }),
      Appointment.countDocuments({ status: "Cancelled" }),
    ]);

    res.json({ doctors, patients, appointments, departments, scheduled, completed, cancelled });
  } catch (error) {
    console.error("Dashboard stats error:", error);
    res.status(500).json({ message: "Dashboard statistikalarini olishda xatolik", error: error.message });
  }
}

module.exports = { getDashboardStats };
