const Department = require("../models/Department");

// ==================== GET ALL DEPARTMENTS ====================

const getDepartments = async (req, res) => {
  try {
    const q = String(req.query.q || "").trim();
    const filter = q ? { $or: [
      { name: { $regex: q, $options: "i" } },
      { description: { $regex: q, $options: "i" } },
      { status: { $regex: q, $options: "i" } },
    ] } : {};
    const departments = await Department.find(filter).sort({
      createdAt: -1,
    });

    res.status(200).json(departments);
  } catch (error) {
    console.error("Get departments error:", error);

    res.status(500).json({
      message: "Departmentlarni olishda xatolik",
      error: error.message,
    });
  }
};

// ==================== GET DEPARTMENT BY ID ====================

const getDepartmentById = async (req, res) => {
  try {
    const department = await Department.findById(
      req.params.id
    );

    if (!department) {
      return res.status(404).json({
        message: "Department topilmadi",
      });
    }

    res.status(200).json(department);
  } catch (error) {
    console.error("Get department error:", error);

    res.status(500).json({
      message: "Departmentni olishda xatolik",
      error: error.message,
    });
  }
};

// ==================== CREATE DEPARTMENT ====================

const createDepartment = async (req, res) => {
  try {
    const {
      name,
      description,
      icon,
      status,
    } = req.body;

    if (!name) {
      return res.status(400).json({
        message: "Department nomi majburiy",
      });
    }

    const existingDepartment =
      await Department.findOne({ name });

    if (existingDepartment) {
      return res.status(400).json({
        message: "Bu department allaqachon mavjud",
      });
    }

    const department = await Department.create({
      name,
      description: description || "",
      icon: icon || "🏥",
      status: status || "Active",
    });

    res.status(201).json(department);
  } catch (error) {
    console.error("Create department error:", error);

    res.status(500).json({
      message: "Department yaratishda xatolik",
      error: error.message,
    });
  }
};

// ==================== UPDATE DEPARTMENT ====================

const updateDepartment = async (req, res) => {
  try {
    const {
      name,
      description,
      icon,
      status,
    } = req.body;

    const department =
      await Department.findById(req.params.id);

    if (!department) {
      return res.status(404).json({
        message: "Department topilmadi",
      });
    }

    if (name && name !== department.name) {
      const existingDepartment =
        await Department.findOne({
          name,
          _id: { $ne: req.params.id },
        });

      if (existingDepartment) {
        return res.status(400).json({
          message: "Bu department allaqachon mavjud",
        });
      }
    }

    department.name = name || department.name;

    department.description =
      description !== undefined
        ? description
        : department.description;

    department.icon =
      icon !== undefined
        ? icon
        : department.icon;

    department.status =
      status || department.status;

    await department.save();

    res.status(200).json(department);
  } catch (error) {
    console.error("Update department error:", error);

    res.status(500).json({
      message: "Departmentni yangilashda xatolik",
      error: error.message,
    });
  }
};

// ==================== DELETE DEPARTMENT ====================

const deleteDepartment = async (req, res) => {
  try {
    const department =
      await Department.findById(req.params.id);

    if (!department) {
      return res.status(404).json({
        message: "Department topilmadi",
      });
    }

    await Department.findByIdAndDelete(
      req.params.id
    );

    res.status(200).json({
      message: "Department o'chirildi",
    });
  } catch (error) {
    console.error("Delete department error:", error);

    res.status(500).json({
      message: "Departmentni o'chirishda xatolik",
      error: error.message,
    });
  }
};

module.exports = {
  getDepartments,
  getDepartmentById,
  createDepartment,
  updateDepartment,
  deleteDepartment,
};