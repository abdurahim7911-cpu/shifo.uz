const dotenv = require("dotenv");
const connectDB = require("./config/db");
const User = require("./models/User");

dotenv.config();

async function createAdmin() {
  try {
    await connectDB();

    const existingUser = await User.findOne({
      email: "admin@medcare.com",
    });

    if (existingUser) {
      console.log("Admin user allaqachon mavjud");
      process.exit(0);
    }

    const user = await User.create({
      name: "Admin",
      email: "admin@medcare.com",
      password: "admin123",
      role: "Admin",
    });

    console.log("Admin user yaratildi!");
    console.log("Email: admin@medcare.com");
    console.log("Password: admin123");

    process.exit(0);
  } catch (error) {
    console.error(
      "Admin yaratishda xatolik:",
      error
    );

    process.exit(1);
  }
}

createAdmin();