# MedCare ONE

MedCare Hospital Management System — backend va frontend bitta loyiha ichida.

## Ishga tushirish (Windows PowerShell)

```powershell
cd "$HOME\Desktop\MedCare_ONE"
npm run setup
npm run dev
```

`npm run dev` ikkala serverni birga ishga tushiradi:

- Frontend: http://localhost:5173
- Backend: http://localhost:5000
- API: http://localhost:5000/api
- Frontenddagi `/api/*` so'rovlar Vite proxy orqali backendga o'tadi.

### Admin login

- Email: `admin@medcare.com`
- Password: `admin123`

MongoDB o'rnatilmagan yoki ishlamayotgan bo'lsa ham demo admin login ishlaydi. MongoDB ulanganida ma'lumotlar bazasi ishlatiladi.

## Agar 5000-port band bo'lsa

Boshqa terminalda:

```powershell
Get-NetTCPConnection -LocalPort 5000 -ErrorAction SilentlyContinue
```

Keraksiz Node jarayonlarini yopib, `npm run dev` ni qayta ishga tushiring.
